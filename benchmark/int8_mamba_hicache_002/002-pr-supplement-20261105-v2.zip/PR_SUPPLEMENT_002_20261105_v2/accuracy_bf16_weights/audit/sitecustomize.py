"""Experiment-only deterministic GPU eviction and transport audit hooks."""
import os

if os.environ.get('CHECKPOINT_ACCURACY_RUN'):
    import importlib.abc
    import importlib.util
    import json
    import hashlib
    from pathlib import Path
    import sys
    import time

    compat=os.environ.get('CHECKPOINT_ACCURACY_KDA_COMPAT')
    if compat:
        class KimiCompatibility(importlib.abc.MetaPathFinder):
            def find_spec(self, fullname, path=None, target=None):
                if fullname=='sglang.srt.models.kimi_linear':
                    return importlib.util.spec_from_file_location(fullname,compat)
        sys.meta_path.insert(0,KimiCompatibility())

    import torch
    from sglang.srt.mem_cache.base_prefix_cache import EvictParams
    from sglang.srt.mem_cache.pool_host.mamba import MambaPoolHost
    from sglang.srt.mem_cache.unified_radix_cache import UnifiedRadixCache

    run=Path(os.environ['CHECKPOINT_ACCURACY_RUN']);audit=run/'audit';audit.mkdir(exist_ok=True)
    verify=os.environ.get('CHECKPOINT_ACCURACY_VERIFY')=='1'
    warm_hash=os.environ.get('CHECKPOINT_ACCURACY_WARM_HASH')=='1'
    def tensor_hash(tensor):
        return hashlib.sha256(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
    def command():
        try:return json.loads((run/'command.json').read_text())
        except (OSError,ValueError):return {}
    def emit(event,**fields):
        c=command()
        with (audit/f'{os.getpid()}.jsonl').open('a') as f:
            f.write(json.dumps(dict(event=event,time=time.time(),pid=os.getpid(),rid=c.get('rid'),**fields))+'\n')

    if os.environ.get('CHECKPOINT_ACCURACY_NONATOMIC_MARLIN')=='1':
        # Independent numerical-control setting for every KDA arm. Keep native
        # weights, dtype and kernels, using their existing non-atomic reduction.
        import importlib
        import functools
        for name in ['marlin_utils','marlin_utils_fp4','marlin_utils_fp8']:
            module=importlib.import_module('sglang.srt.layers.quantization.'+name)
            module.should_use_atomic_add_reduce=lambda *args,**kwargs:False
        marlin_moe=importlib.import_module('sglang.srt.layers.moe.fused_moe_triton.fused_marlin_moe')
        original_marlin=marlin_moe.moe_wna16_marlin_gemm
        first_marlin=[True]
        @functools.wraps(original_marlin)
        def non_atomic_marlin(*args,**kwargs):
            kwargs['use_atomic_add']=False
            if first_marlin[0]:
                emit('marlin_moe_non_atomic',use_atomic_add=False);first_marlin[0]=False
            return original_marlin(*args,**kwargs)
        marlin_moe.moe_wna16_marlin_gemm=non_atomic_marlin
        emit('marlin_reduction_control',enabled=True)

    original_match=UnifiedRadixCache.match_prefix
    def match(self,params):
        c=command();rid=getattr(params.req,'rid',None)
        if rid is not None and rid==c.get('rid') and c.get('tier')=='l2' and c.get('kind')!='warm' and getattr(self,'_accuracy_evicted_rid',None)!=rid:
            # Use the production backup completion and eviction paths. No tree
            # values, tensors, codec or model outputs are manually rewritten.
            self.writing_check(write_back=True)
            torch.cuda.synchronize()
            result=self.evict(EvictParams(num_tokens=c['cut'],mamba_num=32))
            self._accuracy_evicted_rid=rid
            emit('forced_gpu_eviction',result=str(result),cut=c['cut'])
        result=original_match(self,params)
        if rid is not None and rid==c.get('rid'):
            emit('match',request_rid=rid,device_prefix_len=result.device_prefix_len,
                 host_hit_length=result.host_hit_length,mamba_host_hit_length=result.mamba_host_hit_length)
        return result
    UnifiedRadixCache.match_prefix=match

    backup_original=MambaPoolHost.backup_from_device_all_layer
    load_original=MambaPoolHost.load_to_device_per_layer
    def check(self,hi,di,layer=None):
        torch.cuda.synchronize()
        h=hi.cpu().long();d=di.to(self.buffer_info.temporal.device).long()
        if layer is None:
            assert torch.equal(self.temporal_buffer[h,:,0].transpose(0,1),self.buffer_info.temporal[:,d].cpu())
            for host,dev in zip(self.conv_buffer,self.buffer_info.conv):
                assert torch.equal(host[h,:,0].transpose(0,1),dev[:,d].cpu())
        for host,dev in zip(self.slot_state_buffers,self.slot_state_device_tensors):
            assert torch.equal(host[h],dev[d].cpu())
    def backup(self,pool,hi,di,*args,**kwargs):
        result=backup_original(self,pool,hi,di,*args,**kwargs)
        if verify:check(self,hi,di)
        extra={}
        if warm_hash:
            torch.cuda.synchronize()
            idx=di.to(self.buffer_info.temporal.device).long()
            extra=dict(temporal_sha256=tensor_hash(self.buffer_info.temporal[:,idx]),
                conv_sha256=[tensor_hash(c[:,idx]) for c in self.buffer_info.conv])
        emit('mamba_d2h',slots=di.numel(),dtype=str(self.buffer_info.temporal.dtype),verified=verify,**extra)
        return result
    def load(self,pool,hi,di,layer,*args,**kwargs):
        result=load_original(self,pool,hi,di,layer,*args,**kwargs)
        if layer==self.num_mamba_layers-1:
            if verify:check(self,hi,di)
            emit('mamba_h2d',slots=di.numel(),dtype=str(self.buffer_info.temporal.dtype),verified=verify)
        return result
    MambaPoolHost.backup_from_device_all_layer=backup
    MambaPoolHost.load_to_device_per_layer=load

    if warm_hash:
        from sglang.srt.model_executor.model_runner import ModelRunner
        original_cow=ModelRunner._maybe_execute_deferred_mamba_cow_and_clear
        def cow(self,batch):
            c=command();state=self.token_to_kv_pool_allocator.state
            src=batch.mamba_cow_src_indices;dst=batch.mamba_cow_dst_indices
            expected=None
            if src is not None and len(src) and state.ckpt_pool is None:
                ids=self.runner_ids.state_ids(self.req_to_token_pool.state_sub_pool)
                physical_src=ids.ids(src);physical_dst=ids.ids(dst)
                torch.cuda.synchronize()
                expected=(state.pool.mamba_cache.temporal[:,physical_src].clone(),
                    [v[:,physical_src].clone() for v in state.pool.mamba_cache.conv])
            clears=[] if batch.mamba_clear_indices is None else batch.mamba_clear_indices.cpu().tolist()
            result=original_cow(self,batch)
            if expected is not None:
                torch.cuda.synchronize()
                assert torch.equal(state.pool.mamba_cache.temporal[:,physical_dst],expected[0])
                assert all(torch.equal(v[:,physical_dst],ref) for v,ref in zip(state.pool.mamba_cache.conv,expected[1]))
            emit('cow_check',has_source=expected is not None,clear_slots=clears,copy_exact=True)
            return result
        ModelRunner._maybe_execute_deferred_mamba_cow_and_clear=cow

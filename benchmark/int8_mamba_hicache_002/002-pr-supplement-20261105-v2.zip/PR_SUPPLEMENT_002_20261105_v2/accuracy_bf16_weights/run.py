"""Serial, paired BF16/INT8 checkpoint accuracy and fixed-reference scoring."""
import argparse
import collections
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback

import requests

ROOT=Path(__file__).resolve().parent
SOURCE=Path('/mnt/sll/sglang-main-int8-hicache-002-20261103')
DEPS=Path('/mnt/sll/experiments/codec-main-20261102/deps')
PREVIOUS=Path('/mnt/sll/experiments/int8-hicache-002-port-20261103')
URL='http://127.0.0.1:18090'
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())

def save(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n');temporary.replace(path)

def canonical_number(value):
    try:return str(Decimal(value.replace(',','').strip()).normalize())
    except (InvalidOperation,AttributeError):return None

def extract_answer(text):
    matches=re.findall(r'####\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)',text)
    return canonical_number(matches[-1]) if matches else None

def events(folder):
    return [json.loads(line) for path in (folder/'audit').glob('*.jsonl') for line in path.read_text().splitlines()]

class Service:
    def __init__(self,stage,model,fmt,attempt=''):
        self.model=model;self.fmt=fmt
        self.folder=ROOT/'runs'/f'{stage}_{model}_{fmt}{attempt}';self.folder.mkdir(parents=True,exist_ok=True)
        assert not (self.folder/'DONE').exists(),'completed run must not be overwritten'
        self.epoch=len(list(self.folder.glob('launch*.json')))
        epoch_suffix='' if self.epoch==0 else f'_restart{self.epoch}'
        self.results=[]
        previous=self.folder/'results.jsonl'
        if previous.exists():
            parsed=[]
            for line in previous.read_text().splitlines():
                try:parsed.append(json.loads(line))
                except ValueError:pass
            counts=collections.Counter(r['index'] for r in parsed)
            required={(tier,kind) for tier in ['l1','l2'] for kind in ['generation','scoring']}
            complete={i for i,n in counts.items() if n==4 and {(r['tier'],r['kind']) for r in parsed if r['index']==i}==required}
            self.results=[r for r in parsed if r['index'] in complete]
            previous.rename(self.folder/f'results_before_restart{self.epoch}.jsonl')
            previous.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in self.results))
            save(self.folder/f'resumption{self.epoch}.json',dict(complete_examples_retained=len(complete),
                partial_records_discarded=len(parsed)-len(self.results),criterion='retain every structurally complete 4-record case regardless of answer'))
        self.session=requests.Session()
        args=[sys.executable,'-m','sglang.launch_server','--model-path',PROTOCOL['models'][model]['model'],
            '--tokenizer-path',PROTOCOL['models'][model]['tokenizer'],'--trust-remote-code',
            '--host','127.0.0.1','--port','18090','--tp-size','2',
            '--dtype','bfloat16',
            '--attention-backend','flashinfer','--linear-attn-decode-backend','triton',
            '--kv-cache-dtype','fp8_e4m3' if model=='gdn' else 'auto',
            '--cuda-graph-backend-prefill','disabled','--chunked-prefill-size','2048',
            '--max-prefill-tokens','8192','--page-size','256',
            '--mamba-radix-cache-strategy','extra_buffer_lazy','--mamba-ssm-dtype','bfloat16',
            '--mem-fraction-static',str(PROTOCOL['mem_fraction_static']),'--max-running-requests','1',
            '--cuda-graph-max-bs-decode','1','--context-length','8192','--max-total-tokens','32768',
            '--max-mamba-cache-size','32','--enable-hierarchical-cache','--hicache-ratio','2',
            '--hicache-io-backend','kernel','--hicache-mem-layout','page_first',
            '--hicache-write-policy','write_through','--enable-cache-report','--random-seed','20261103']
        if PROTOCOL.get('language_model_only'):args+=['--language-model-only']
        if fmt=='int8':args+=['--enable-int8-mamba-checkpoint','--int8-mamba-ckpt-size','16']
        if model=='kda':args+=['--dtype','bfloat16']
        env=os.environ.copy();env.update(PYTHONPATH=f'{SOURCE/"python"}:{ROOT/"audit"}:{DEPS}',
            CUDA_VISIBLE_DEVICES='0,1',SGLANG_RUST_BUILD_MODE='auto',SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN='1',
            CHECKPOINT_ACCURACY_RUN=str(self.folder),CHECKPOINT_ACCURACY_VERIFY='1' if stage=='smoke' else '0')
        if model=='kda':env['CHECKPOINT_ACCURACY_KDA_COMPAT']=str(PREVIOUS/'kimi_linear_awq_compat.py')
        env['CHECKPOINT_ACCURACY_NONATOMIC_MARLIN']=str(int(model=='kda' and PROTOCOL['models']['kda'].get('non_atomic_marlin',False)))
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==PROTOCOL['source_commit']
        save(self.folder/f'launch{epoch_suffix}.json',dict(args=args,env={k:v for k,v in env.items() if k.startswith(('CHECKPOINT_','SGLANG_','PYTHONPATH','CUDA_VISIBLE'))},
            source_commit=PROTOCOL['source_commit'],runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            audit_sha256=hashlib.sha256((ROOT/'audit/sitecustomize.py').read_bytes()).hexdigest(),
            protocol_sha256=hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest()))
        self.log=(self.folder/f'server{epoch_suffix}.log').open('w')
        self.proc=subprocess.Popen(args,cwd=SOURCE,env=env,stdout=self.log,stderr=subprocess.STDOUT,start_new_session=True)
    def __enter__(self):
        try:
            deadline=time.monotonic()+1500
            while True:
                if self.proc.poll() is not None:raise RuntimeError(f'server exited: {self.folder}')
                try:
                    if self.session.get(URL+'/health',timeout=1).ok:break
                except requests.RequestException:pass
                assert time.monotonic()<deadline,'startup timeout'
                time.sleep(1)
            suffix='' if self.epoch==0 else f'_restart{self.epoch}'
            save(self.folder/f'server_info{suffix}.json',self.session.get(URL+'/get_server_info',timeout=60).json())
            return self
        except BaseException:
            self.close();raise
    def close(self):
        if self.proc.poll() is None:
            os.killpg(self.proc.pid,signal.SIGTERM)
            try:self.proc.wait(timeout=45)
            except subprocess.TimeoutExpired:
                os.killpg(self.proc.pid,signal.SIGKILL);self.proc.wait()
        self.log.close();self.session.close()
    def __exit__(self,*_):self.close()
    def control(self,rid,tier,kind,cut):
        save(self.folder/'command.json',dict(rid=rid,tier=tier,kind=kind,cut=cut))
    def generate(self,body):
        response=self.session.post(URL+'/generate',json=body,timeout=300)
        response.raise_for_status();data=response.json()
        assert 'error' not in data,data
        return data
    def trial(self,row,tier,kind,trial_tag='formal'):
        rid=f'{self.model}_{self.fmt}_{tier}_{row["index"]}_{kind}_{trial_tag}_epoch{self.epoch}'
        self.control(rid+'_flush',tier,'flush',row['cut'])
        response=self.session.post(URL+'/flush_cache?timeout=30',timeout=90);response.raise_for_status()
        assert response.text.startswith('Cache flushed.'),response.text
        self.control(rid+'_warm',tier,'warm',row['cut'])
        warm=self.generate(dict(rid=rid+'_warm',input_ids=row['prompt_ids'][:row['cut']],
            sampling_params=dict(temperature=0,max_new_tokens=1,ignore_eos=True)))
        assert warm['meta_info']['completion_tokens']==1
        self.control(rid,tier,kind,row['cut'])
        start=time.monotonic()
        if kind=='generation':
            body=dict(rid=rid,input_ids=row['prompt_ids'],sampling_params=PROTOCOL['generation'])
        else:
            body=dict(rid=rid,input_ids=row['prompt_ids']+row['reference_ids'],
                sampling_params=dict(temperature=0,max_new_tokens=1,ignore_eos=True),
                return_logprob=True,logprob_start_len=len(row['prompt_ids'])-1,return_text_in_logprobs=False)
        data=self.generate(body);meta=data['meta_info'];detail=meta.get('cached_tokens_details') or {}
        assert meta['cached_tokens']==row['cut'],(rid,meta)
        assert detail.get('device',0)==(row['cut'] if tier=='l1' else 0),(rid,detail)
        assert detail.get('host',0)==(row['cut'] if tier=='l2' else 0),(rid,detail)
        assert meta.get('num_retractions',0)==0
        record=dict(model=self.model,format=self.fmt,tier=tier,kind=kind,index=row['index'],position=row['position'],
            rid=rid,cut=row['cut'],prompt_len=len(row['prompt_ids']),elapsed_s=time.monotonic()-start,meta=meta)
        if kind=='generation':
            assert len(data['output_ids'])==meta['completion_tokens']
            prediction=extract_answer(data['text'])
            record.update(text=data['text'],output_ids=data['output_ids'],prediction=prediction,gold=canonical_number(row['gold']),
                correct=prediction==canonical_number(row['gold']),format_error=prediction is None,
                truncated=meta.get('finish_reason',{}).get('type')=='length')
        else:
            values=meta['input_token_logprobs'];n=len(row['reference_ids'])
            assert len(values)>=n,(rid,len(values),n,values[:3])
            scored=values[-n:]
            assert [v[1] for v in scored]==row['reference_ids'],(rid,'teacher forcing token alignment')
            probs=[v[0] for v in scored]
            assert all(p is not None and math.isfinite(p) for p in probs),(rid,'non-finite logprob')
            record.update(reference_logprobs=probs,reference_token_count=n,nll=-sum(probs)/n,
                          discarded_leading_logprob_count=len(values)-n)
            record['meta'].pop('input_token_logprobs',None)
        target='results.jsonl' if trial_tag=='formal' else 'restart_check.jsonl'
        with (self.folder/target).open('a') as out:out.write(json.dumps(record,ensure_ascii=False)+'\n')
        if trial_tag=='formal':self.results.append(record)
        return record
    def finish(self,expected):
        assert len(self.results)==expected,(len(self.results),expected)
        audit=events(self.folder)
        counts=collections.Counter()
        for record in self.results:
            rows=[r for r in audit if r.get('rid')==record['rid']]
            pids={r['pid'] for r in rows if r['event']=='match'}
            assert len(pids)==2,(record['rid'],pids)
            for pid in pids:
                loads=[r for r in rows if r['pid']==pid and r['event']=='mamba_h2d']
                evictions=[r for r in rows if r['pid']==pid and r['event']=='forced_gpu_eviction']
                assert bool(loads)==(record['tier']=='l2'),(record['rid'],'H2D',pid)
                assert bool(evictions)==(record['tier']=='l2'),(record['rid'],'eviction',pid)
            counts[(record['tier'],record['kind'])]+=1
        summary=dict(records=len(self.results),path_counts={str(k):v for k,v in counts.items()},
            accuracy={tier:sum(r['correct'] for r in self.results if r['tier']==tier and r['kind']=='generation')/counts[(tier,'generation')] for tier in ['l1','l2']},
            truncated=sum(r.get('truncated',False) for r in self.results),
            format_errors=sum(r.get('format_error',False) for r in self.results),
            audited_ranks=2,actual_l1_l2_paths_valid=True)
        save(self.folder/'summary.json',summary);(self.folder/'DONE').touch()
        return summary

def run(stage,model,fmt,limit=None,attempt=''):
    rows=[json.loads(line) for line in (ROOT/f'inputs_{model}.jsonl').read_text().splitlines()]
    if stage=='smoke':selected=rows[:64 if limit is None else limit]
    elif stage=='full':
        assert (ROOT/'SMOKE_GATE_PASSED.json').exists(),'all four smoke servers must pass before full test'
        selected=rows[64:]
        if limit:selected=selected[:limit]
    else:raise ValueError(stage)
    with Service(stage,model,fmt,attempt) as service:
        start=time.monotonic()
        if stage=='full':
            smoke=[json.loads(line) for line in (ROOT/'runs'/f'smoke_{model}_{fmt}'/'results.jsonl').read_text().splitlines()]
            lookup={(r['index'],r['tier'],r['kind']):r for r in smoke}
            checks=[]
            for row in rows[:8]:
                for tier in ['l1','l2']:
                    for kind in ['generation','scoring']:
                        replay=service.trial(row,tier,kind,'restart_check');reference=lookup[(row['index'],tier,kind)]
                        check=dict(index=row['index'],tier=tier,kind=kind)
                        if kind=='generation':check.update(output_equal=replay['output_ids']==reference['output_ids'],accuracy_equal=replay['correct']==reference['correct'])
                        else:check['max_abs_logprob']=max(abs(a-b) for a,b in zip(replay['reference_logprobs'],reference['reference_logprobs']))
                        checks.append(check)
            save(service.folder/f'restart_comparison_epoch{service.epoch}.json',checks)
        complete={r['index'] for r in service.results}
        todo=[r for r in selected if r['index'] not in complete]
        for i,row in enumerate(todo):
            # Same fixed order in both formats. Generation and teacher forcing
            # each get a fresh cache, preventing reference-answer contamination.
            for tier in ['l1','l2']:
                for kind in ['generation','scoring']:service.trial(row,tier,kind)
            progress=dict(stage=stage,model=model,format=fmt,completed=len(complete)+i+1,total=len(selected),
                elapsed_s=time.monotonic()-start,last_index=row['index'],
                correct_l1=sum(r['correct'] for r in service.results if r['tier']=='l1' and r['kind']=='generation'),
                correct_l2=sum(r['correct'] for r in service.results if r['tier']=='l2' and r['kind']=='generation'),
                truncated=sum(r.get('truncated',False) for r in service.results))
            save(service.folder/'progress.json',progress)
            if i%8==0 or i+1==len(selected):print(json.dumps(progress),flush=True)
        summary=service.finish(len(selected)*4);print(json.dumps(summary),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','full']);p.add_argument('model',choices=['gdn','kda'])
    p.add_argument('format',choices=['bf16','int8']);p.add_argument('--limit',type=int);p.add_argument('--attempt',default='')
    args=p.parse_args()
    try:run(args.stage,args.model,args.format,args.limit,args.attempt)
    except BaseException:
        traceback.print_exc();raise

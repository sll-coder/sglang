"""Paired task accuracy and aligned ground-truth logprob analysis."""
import argparse
import collections
import json
import math
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())

def wilson(k,n):
    z=1.959963984540054;p=k/n;denom=1+z*z/n
    center=(p+z*z/(2*n))/denom
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/denom
    return [center-half,center+half]

def paired_interval(values):
    a=np.asarray(values,dtype=np.float64);rng=np.random.default_rng(42)
    if np.ptp(a)==0:return [float(a[0]),float(a[0])]
    draws=[]
    for _ in range(20):
        draws.extend(a[rng.integers(0,len(a),size=(500,len(a)))].mean(axis=1).tolist())
    return np.quantile(draws,[0.025,0.975]).tolist()

def read_model(model):
    data={}
    completed_runs=[]
    for stage in ['smoke','full']:
        for fmt in ['bf16','int8']:
            folder=ROOT/'runs'/f'{stage}_{model}_{fmt}'
            path=folder/'results.jsonl'
            if not path.exists():continue
            if (folder/'DONE').exists():completed_runs.append(folder.name)
            lines=path.read_text().splitlines()
            for line in lines:
                try:r=json.loads(line)
                except ValueError:continue
                key=(r['index'],f'{fmt}_{r["tier"]}',r['kind'])
                assert key not in data,('duplicate formal result',key)
                data[key]=r
    ids=sorted({key[0] for key in data})
    complete=[i for i in ids if all((i,condition,kind) in data for condition in PROTOCOL['conditions'] for kind in ['generation','scoring'])]
    return data,complete,completed_runs

def comparison(data,ids,a,b):
    accuracy=[];token_deltas=[];nll_deltas=[];outputs_equal=0;worse=[];better=[];changed=[];nll_cases=[]
    for index in ids:
        ga=data[(index,a,'generation')];gb=data[(index,b,'generation')]
        sa=data[(index,a,'scoring')];sb=data[(index,b,'scoring')]
        accuracy.append(int(gb['correct'])-int(ga['correct']))
        if ga['correct'] and not gb['correct']:worse.append(index)
        if not ga['correct'] and gb['correct']:better.append(index)
        same=ga['output_ids']==gb['output_ids'];outputs_equal+=int(same)
        if not same:changed.append(index)
        delta=np.asarray(sb['reference_logprobs'])-np.asarray(sa['reference_logprobs'])
        token_deltas.extend(delta.tolist());nll_deltas.append(sb['nll']-sa['nll'])
        nll_cases.append(dict(index=index,delta_nll=sb['nll']-sa['nll'],max_abs_logprob=float(abs(delta).max()),
            baseline_correct=ga['correct'],candidate_correct=gb['correct'],baseline_answer=ga['prediction'],candidate_answer=gb['prediction']))
    d=np.asarray(token_deltas,dtype=np.float64);abs_d=abs(d);n=len(ids)
    result=dict(baseline=a,candidate=b,n=n,accuracy_delta=sum(accuracy)/n,
        accuracy_delta_paired_bootstrap95=paired_interval(accuracy),correct_to_wrong=len(worse),wrong_to_correct=len(better),
        correct_to_wrong_indices=worse,wrong_to_correct_indices=better,
        output_sequences_equal=outputs_equal,output_sequence_equal_rate=outputs_equal/n,output_changed_indices=changed,
        scored_tokens=len(d),mean_signed_delta_logprob=float(d.mean()),mean_abs_delta_logprob=float(abs_d.mean()),
        abs_delta_logprob_quantiles={str(q):float(np.quantile(abs_d,q)) for q in [0.5,0.9,0.95,0.99,0.999]},
        max_abs_delta_logprob=float(abs_d.max()),exact_logprob_tokens=int((d==0).sum()),
        reference_token_weighted_delta_nll=float(-d.mean()),mean_example_delta_nll=float(np.mean(nll_deltas)),
        worst_examples=sorted(nll_cases,key=lambda r:r['max_abs_logprob'],reverse=True)[:20])
    flips=len(worse)+len(better)
    if flips:
        # Exact two-sided McNemar via the binomial distribution on discordant cases.
        k=min(len(worse),len(better))
        result['mcnemar_exact_p']=min(1.0,2*sum(math.comb(flips,j) for j in range(k+1))/2**flips)
    else:
        result['mcnemar_exact_p']=1.0
        result['zero_observed_flip_one_sided95_rate_upper']=1-0.05**(1/n)
    return result

def analyze(final=False):
    result=dict(protocol_sha256=__import__('hashlib').sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),
        source_commit=PROTOCOL['source_commit'],test_rows=PROTOCOL['test_rows'],final=final,models={})
    comparisons=[('bf16_l1','int8_l1'),('bf16_l1','bf16_l2'),('int8_l1','int8_l2'),('bf16_l2','int8_l2')]
    for model in ['gdn']:
        data,ids,runs=read_model(model)
        if final:assert len(ids)==PROTOCOL['test_rows'],(model,len(ids))
        if not ids:continue
        conditions={}
        for condition in PROTOCOL['conditions']:
            generated=[data[(i,condition,'generation')] for i in ids]
            scoring=[data[(i,condition,'scoring')] for i in ids]
            correct=sum(r['correct'] for r in generated)
            total_tokens=sum(r['reference_token_count'] for r in scoring)
            conditions[condition]=dict(n=len(ids),correct=correct,accuracy=correct/len(ids),accuracy_wilson95=wilson(correct,len(ids)),
                truncated=sum(r['truncated'] for r in generated),format_errors=sum(r['format_error'] for r in generated),
                generated_tokens=sum(len(r['output_ids']) for r in generated),
                reference_tokens=total_tokens,reference_token_weighted_nll=sum(r['nll']*r['reference_token_count'] for r in scoring)/total_tokens,
                mean_example_nll=sum(r['nll'] for r in scoring)/len(ids))
        result['models'][model]=dict(complete_examples=len(ids),complete_indices=ids,completed_runs=runs,conditions=conditions,
            comparisons={f'{b}_minus_{a}':comparison(data,ids,a,b) for a,b in comparisons})
    target=ROOT/('RESULTS.json' if final else 'PARTIAL_RESULTS.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({model:dict(n=r['complete_examples'],conditions={c:v['accuracy'] for c,v in r['conditions'].items()},
        comparisons={c:dict(delta=v['accuracy_delta'],max_abs_logprob=v['max_abs_delta_logprob']) for c,v in r['comparisons'].items()}) for model,r in result['models'].items()},indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');args=p.parse_args();analyze(args.final)

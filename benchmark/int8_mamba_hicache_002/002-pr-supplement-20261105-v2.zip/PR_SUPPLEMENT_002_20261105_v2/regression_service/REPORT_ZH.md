# 002 最新 main 适配和真实服务验证

完成日期：2026-11-03。

基线：官方 main `af98fcd545f90eaaf4b26d20bfb42e3ec1d91020`，本次开始时重新 fetch 得到。

工作树：`/mnt/sll/sglang-main-int8-hicache-002-20261103`。

独立分支：`feat/int8-mamba-hicache-002-20261103`。

本地提交：`15a00b66a6b388c5c795d533e4ef21a6ee92ff5e`；工作树干净。改动为 563 行增加、24 行删除。

## 结果

002 已按当前 main 接口适配，完成 checkpoint 耗尽回归，以及 GDN/KDA 的真实 TP2 服务验证。两种模型都实际发生了压缩 checkpoint 的 GPU L1→host L2→GPU L1 回迁、驱逐、并发请求和重复恢复。

001 和 003 没有合入本分支，其原工作树仍干净。当前 INT8 codec 类与 main 完全相同，002 不需要融合 codec。001 的通用 controller load 和 load-back admission 方法也保持 main 原样；其既有回滚和 pin handoff 问题仍由独立的 001 处理。

改动共 11 个文件：7 个生产文件、4 个现有测试文件；没有新增算子、环境变量或服务接口。

## 具体改动

1. **压缩池元数据**：增加 `MambaCheckpointDevicePool`，通过现有 `DevicePoolInfo` 公布 INT8 qdata、native scale、native conv、checkpoint 容量和实际字节数。host 不再误读 active BF16 pool，也不建立 BF16 镜像。
2. **组装及驱逐**：Mamba 和 Mamba+SWA host stack 在 INT8 模式选择 checkpoint pool 和 checkpoint allocator；回迁驱逐按 checkpoint 空间计算，保持运行请求的 active allocator 语义不变。
3. **恢复路径**：L2 回迁只恢复树节点的 checkpoint；随后设置 request deferred CoW，把该 checkpoint 反量化到独立 active slot。禁止原始 INT8 payload 直接写入 request 的 BF16 slot。
4. **传输等待**：全状态反量化前调用已有 `layer_router.wait_for_part(STATE_PART)`，等待相关层完成 H2D。
5. **耗尽及异常**：checkpoint 全被占用/pin 时返回“本次不缓存”；先预留 checkpoint，再申请替代 tracking slot；编码成功后才 donation。申请或编码失败时归还保留资源，保持 request tracking 所有权。
6. **支持范围**：在完成上述接线后开放受限配置；启动和 runtime storage attach 都拒绝未经覆盖的组合，L3 后端不能运行时绕过限制接入。

复用 main 的 `MambaPoolHost` 传输 qdata/scale/conv，没有照搬旧版专用 host mover。现有 side-state scale 搬运仍包含 blocking copy；本次没有声称优化该部分耗时。

## checkpoint 耗尽的 before/after 回归

在未修复 main 上运行新增的 5 个 admission 方法：**3 failed、2 passed**。失败覆盖 finished/unfinished checkpoint 耗尽，以及编码异常后的资源泄漏。保留了原始 `exhaustion_before.log`。

修复后 5 个方法全部通过，覆盖：

| 条件 | 修复后的行为 |
|---|---|
| checkpoint 全被占用且不可驱逐，unfinished request | 返回 0，不 donation；tracking `[2,3]`、active 空闲数保持不变 |
| 同上，finished request | 返回 0、没有新 checkpoint，保留原状态供正常清理 |
| checkpoint 已预留，但 active slot 申请失败 | 归还 checkpoint，不改变 tracking |
| 真实 codec 源索引错误 | 抛出原异常，归还 checkpoint 和新 active slot，tracking 不被替换 |
| eviction 释放一个 checkpoint | 正常缓存；编码数据和 scale 与 eager 参考完全相同 |

测试使用真实分配器、checkpoint pool、storage、component 和 request-table donation；仅在 eviction 外部边界模拟“无可回收槽位”或释放一个真实 reservation。没有把受控 pin 条件描述为完整服务中的并发故障复现。

其他新增方法覆盖压缩池 descriptor/allocator、驱逐容量、错误模型 side state/packed draft 的拒绝、runtime L3 attach 拒绝、启动配置矩阵，以及真实 GPU cache 回迁和 deferred CoW 等待。

GPU 等待用例让 checkpoint 内容在传输 fence 回调中才变为有效值，随后调用真实 ModelRunner restore 和 eager codec；漏掉等待会恢复出错误的零状态。该用例同时验证 qdata、scale、conv 往返一致、checkpoint allocator 减少一槽，以及 request active pool 不被误作 checkpoint 目标。

## 相关回归

| 检查 | 结果 |
|---|---|
| codec/admission、assembler、side state、transfer metadata、Mamba capacity、完整 server-args 文件 | **431 passed、1 skipped、281 subtests passed** |
| GPU codec、HiCache load-back 矩阵、timing、新 INT8 恢复用例 | **82 passed、19 skipped** |
| 原生 Rust Mamba TreeCore 相关项 | **48 passed、534 deselected** |
| 适用 pre-commit hooks、whitespace | **通过** |

CPU 的 1 项 skip 为 CUDA decode 项，已在 GPU 那轮执行。GPU 19 项为配置不适用。CPU/GPU codec 有重复覆盖，不累加为独立测试数量。没有运行完整远端 CI。

## GDN/KDA 真实服务

硬件：2× RTX 5090，TP=2。运行实际模型：

- GDN：`/mnt/sll/models/Qwen3.8-27B-NVFP4`。
- KDA：`/mnt/sll/models/Kimi-Linear-48B-A3B-Instruct-AWQ-4bit`。

每轮固定 active capacity=32、INT8 checkpoint capacity=16、max-running-requests=8、KV capacity=32768；HiCache 使用 kernel IO、page_first、write_through，host ratio=8。保留默认 overlap 和 decode CUDA Graph；prefill CUDA Graph 关闭。所有编解码都使用 main 的 eager 实现。

每轮流程：8 个目标前缀预热 → 8 次串行 L1 参考 → 32 个不同前缀 churn 使 checkpoint 淘汰 → 8 次目标 L2 恢复 → 64 次并发压力请求 → 8 次再次恢复。前缀长 1024；参考查询输入长 1032、输出 16 tokens。

分别运行带逐项同步校验和关闭额外校验的两种模式，共 4 轮、**512 个请求**：

| 模型/模式 | 成功请求 | 客户端并发峰值 | L1 参考 | 首次 L2 恢复 | 并发窗口 | 再次 L2 恢复 | 串行 L1/L2 输出一致 |
|---|---:|---:|---:|---:|---:|---:|---:|
| GDN，逐项校验 | 128/128 | 8 | 8/8 | 8/8 | 56 L2 + 8 L1 | 8/8 | 8/8 |
| GDN，关闭额外校验 | 128/128 | 8 | 8/8 | 8/8 | 56 L2 + 8 L1 | 8/8 | 8/8 |
| KDA，逐项校验 | 128/128 | 8 | 8/8 | 8/8 | 56 L2 + 8 L1 | 8/8 | 8/8 |
| KDA，关闭额外校验 | 128/128 | 8 | 8/8 | 8/8 | 56 L2 + 8 L1 | 8/8 | 8/8 |

L1 请求报告 device=1024、host=0；L2 请求报告 device=0、host=1024。每轮两个 scheduler rank 都记录 **40 个 checkpoint backup slots、72 个 load slots**，以及正常的缓存驱逐。每轮服务日志无 Python traceback，所有请求完成长度正确、没有 retraction。

逐项校验轮在真正的搬运方法之后比较 qdata、scale、conv 的原始值，两张卡均完全一致。额外同步会影响调度，因此另跑关闭这些校验的轮次；现有 generic scale fallback 自身仍有同步，这里不称为完全无同步传输。

实际压缩 host payload 为 GDN **20,643,840 bytes/checkpoint/rank**、KDA **6,062,080 bytes/checkpoint/rank**，均包括 conv 和 scale。此处仅描述数据格式；没有做额外显存峰值或吞吐提升基准。

### GDN 并发输出的批次对照

压力窗口中，把相同目标请求的 C=8 输出与串行参考比较，GDN 并非全部相同（逐项校验轮 4/16、普通轮 6/16）；KDA 为 16/16。不能据此把全部并发输出写成 bit-exact 正确性通过，也不能直接把差异归因于 L2。

为区分批次变化和搬运，额外启动 GDN TP2 服务，使用同一组 8 个输入，分别执行：串行 L1、一次 batched L1、churn 后的 batched L2、再次 batched L1。缓存报告确认各阶段的实际命中层级。

这轮 **72 个请求**全部成功：

- batched L1 vs batched L2：**8/8 output-token 序列相同**。
- 再次 batched L1 vs batched L2：**8/8 相同**。
- 串行 L1 vs batched L1：**3/8 相同**。

因此，批次变化的数值差异可以在 L1 内复现；该控制样本中，固定批次下的 L2 搬运没有新增输出差异。这个结果不证明所有 batch/模型/硬件都 bitwise 稳定，也不证明 INT8 相比 BF16 无量化误差。

### KDA AWQ 的独立兼容层

当前 main 的 Kimi AWQ 加载仍需要前文已验证的 3 处模型兼容调整：shared-expert prefix、MoE prefix，以及 packed module mapping。本次通过实验目录里的单模型 import overlay 应用，配合独立 tokenizer compatibility 目录。

这些调整没有写入 002 工作树。补丁保存在 `kda_compatibility_only.patch`，有效模型代码为 `kimi_linear_awq_compat.py`，每轮 launch manifest 记录 overlay 路径。因此 KDA 结果是 **002 + 独立 AWQ 兼容层** 的验证，不能描述为未调整 main 的 AWQ 开箱即用。

## 范围和后续

首版只开放 CUDA、单机 TP、BF16 active state、kernel/page_first/write_through/cache/extra_buffer_lazy。拒绝 L3、PD、ReplaySSM、speculative、unified-memory、host-only checkpoint 以及额外模型 side state；未宣称验证其他硬件或并行方式。

001 的通用失败回滚和 pin handoff 修复未包含，应继续独立合入并在最终上游基线上复验。003 的融合优化未包含，002 所有结果都来自原 codec。

当前代码和本地验证已可供独立评审；本次没有推送或创建 002 PR。没有为 002 声称吞吐、TTFT 或显存峰值改善。

## 复查材料

- `002-main.patch`、`source_state.json`：独立源码改动、基线、分支和隔离检查。
- `validation.json`：总体结果、边界、JUnit 元数据。
- `exhaustion_before.log`：未修复 main 的失败结果。
- `cpu_regressions.log/xml`、`gpu_regressions.log/xml`、`rust_mamba.log/xml`：回归。
- `precommit_final.log`：最终 lint/格式检查。
- `SERVICE_RESULTS.json`、`GDN_BATCH_CONTROL.json`：真实服务结果。
- 各服务目录：launch、server info、inputs、responses、audit 和 server log。
- `run_service.py`、`audit/sitecustomize.py`：仅用于实验的驱动和校验钩子。

"""Same 72 host state slots in a real service; measure native storage and RSS."""
import concurrent.futures as cf,json,time
from pathlib import Path
import common
ROOT=common.ROOT

def process_snapshot(service):
    import psutil
    rows=[]
    parent=psutil.Process(service.proc.pid)
    for proc in [parent,*parent.children(recursive=True)]:
        try:
            d=dict(pid=proc.pid,name=proc.name())
            text=Path(f'/proc/{proc.pid}/status').read_text()
            for line in text.splitlines():
                if line.startswith(('VmRSS:','VmLck:','VmHWM:')):
                    k,v,*_=line.split();d[k.rstrip(':')]=int(v)*1024
            for line in Path(f'/proc/{proc.pid}/smaps_rollup').read_text().splitlines():
                if line.startswith(('Pss:','Private_Dirty:','Shared_Clean:')):
                    k,v,*_=line.split();d[k.rstrip(':')]=int(v)*1024
            rows.append(d)
        except (OSError,psutil.Error):continue
    return dict(time=time.time(),processes=rows,total_rss=sum(x.get('VmRSS',0) for x in rows),total_pss=sum(x.get('Pss',0) for x in rows),total_locked=sum(x.get('VmLck',0) for x in rows))

def run(service):
    service.phase('memory_startup');before=process_snapshot(service)
    config=dict(length=1024,working_set=72,access='cyclic',concurrency=8,name='same72')
    service.seed(config)
    service.phase('memory_revisit')
    with cf.ThreadPoolExecutor(8) as ex:
        rows=list(ex.map(lambda k:service.query(1024,k,4000+k,n=1),range(72)))
    assert all(x['cached_tokens']==1024 for x in rows)
    time.sleep(1)
    after=process_snapshot(service)
    audit=common.events(service.folder)
    allocations=[x for x in audit if x['event']=='mamba_budget']
    assert len(allocations)==2 and all(x['slots']==72 for x in allocations)
    for a in allocations:
        events=[x for x in audit if x['pid']==a['pid'] and x['event']=='d2h']
        assert events and any(x['host_available']==0 for x in events),(a['pid'],'72 host slots not filled')
    loads=[x for x in audit if x['event']=='load_back' and x['success'] and x['mamba_requested']]
    assert len({x['pid'] for x in loads})==2,'memory traffic must exercise actual L2 on both ranks'
    result=dict(model=service.model,format=service.fmt,slots=72,allocations=allocations,startup=before,filled=after,
        requests=144,revisit_all_cached=True,l2_restore_rids=len({x['rid'] for x in loads}),
        note='Host payload measured from unique actual tensor storage bytes. RSS/PSS/locked process totals include model/runtime/KV allocations and are reported separately; GPU physical pools differ by codec format.')
    common.save(service.folder/'memory_result.json',result)
    common.save(service.folder/'memory_revisit.json',rows)
    print('MEMORY_DONE',service.folder.name,allocations[0]['actual_storage_bytes'],'bytes/rank',flush=True)
    return result

import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'RESULTS.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
models=list(r['memory']);x=np.arange(len(models));width=.35
for fmt,color,offset in [('bf16','#386cb0',-.5),('int8','#e67e22',.5)]:
    axes[0].bar(x+offset*width,[r['memory'][m][fmt+'_payload_GiB'] for m in models],width,label=fmt.upper(),color=color)
axes[0].set_xticks(x,models);axes[0].set_ylabel('Actual Mamba L2 payload / rank (GiB)');axes[0].set_title('Exactly 72 host slots');axes[0].legend();axes[0].grid(axis='y',alpha=.2)
for ax,model in zip(axes[1:],['gdn','kda']):
    v=r['chain'][model];depths=[1,4,16,32]
    for tier,style in [('l1','-o'),('l2','--s')]:
        values=[np.mean([a['mean_abs_delta_logprob'] for a in v['comparisons'][f'int8_{tier}_{d}_minus_bf16_{tier}_{d}']]) for d in depths]
        ax.plot(depths,values,style,label=f'INT8 vs BF16 ({tier.upper()})')
    if v['same_path_repeat_noise']:
        baseline=[np.mean([a['mean_abs_delta_logprob'] for a in v['same_path_repeat_noise'][f'bf16_l1_{d}']]) for d in depths]
        ax.plot(depths,baseline,':^',color='gray',label='BF16 L1 repeat background')
    ax.set_xscale('log',base=2);ax.set_xticks(depths,[str(x) for x in depths]);ax.set_ylim(bottom=0)
    ax.set_xlabel('Actual chained restores (same final 8K prefix)');ax.set_ylabel('Mean absolute fixed-reference logprob difference')
    ax.set_title(model.upper());ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Independent 002 follow-up: equal cache capacity and chained-checkpoint precision')
fig.savefig(ROOT/'FOLLOWUP_SUMMARY.png',dpi=180);fig.savefig(ROOT/'FOLLOWUP_SUMMARY.pdf');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
for ax,model in zip(axes,['gdn','kda']):
    v=r['chain'][model]
    for tier,style in [('l1','-o'),('l2','--s')]:
        values=[np.mean([a['sampled_state_relative_frobenius_mean'] for a in v['comparisons'][f'int8_{tier}_{d}_minus_bf16_{tier}_{d}']]) for d in [1,4,16,32]]
        ax.plot([1,4,16,32],values,style,label=tier.upper())
    ax.set_xscale('log',base=2);ax.set_xticks([1,4,16,32],['1','4','16','32']);ax.set_ylim(bottom=0)
    ax.set_title(model.upper());ax.set_xlabel('Actual chained restores');ax.set_ylabel('Selected-layer relative state error vs BF16');ax.legend();ax.grid(alpha=.2)
fig.suptitle('First/middle/last state layers only; fixed final 8K prefix (not a full-state bound)')
fig.savefig(ROOT/'CHAIN_STATE_ERRORS.png',dpi=180);plt.close(fig)
print('Follow-up figures generated')

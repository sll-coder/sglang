import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for stage in ['pilot','memory','chain']:
    for folder in sorted((ROOT/stage).glob('*')) if (ROOT/stage).exists() else []:
        if folder.name.startswith('diagnostic'):continue
        status='DONE' if (folder/'DONE').exists() else 'FAILED' if (folder/'FAILED').exists() else (folder/'phase.txt').read_text().strip()
        p=folder/'chain_progress.json'
        if p.exists():
            v=json.loads(p.read_text());status+=f" {v['examples_completed']}/{v['examples_total']} examples, {v['records']} records"
        print(stage,folder.name,status)
for flag in ['PILOT_GATE_PASSED.json','MEMORY_ALL_DONE','ALL_RUNS_DONE','ARTIFACTS_READY','PIPELINE_FAILED']:
    if (ROOT/flag).exists():print(flag)

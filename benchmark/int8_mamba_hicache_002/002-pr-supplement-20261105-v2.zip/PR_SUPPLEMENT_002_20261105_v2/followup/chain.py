"""Fixed-final-context genuine chained checkpoint precision, not repeated static restores."""
import collections,json,math,re,time
from decimal import Decimal,InvalidOperation
from pathlib import Path
import common
ROOT=common.ROOT;P=common.P

def canonical(x):
    try:return str(Decimal(x.replace(',','').strip()).normalize())
    except (InvalidOperation,AttributeError):return None

def answer(text):
    m=re.findall(r'####\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)',text)
    return canonical(m[-1]) if m else None

def control(service,rid,**kw):
    common.save(service.folder/'command.json',dict(experiment='chain',rid=rid,**kw))

def request(service,body,expected,tier,rid,kind,depth,step,capture=False):
    control(service,rid,tier=tier,kind=kind,depth=depth,step=step,expected_cached=expected,capture_state=capture)
    response=service.chain_session.post(common.URL+'/generate',json=dict(body,rid=rid),timeout=600)
    response.raise_for_status();data=response.json();assert 'error' not in data,data
    meta=data['meta_info'];detail=meta.get('cached_tokens_details') or {}
    assert meta['cached_tokens']==expected,(rid,expected,meta)
    assert meta.get('num_retractions',0)==0,(rid,meta)
    if expected:
        assert detail.get('device',0)==(expected if tier=='l1' else 0),(rid,detail)
        assert detail.get('host',0)==(expected if tier=='l2' else 0),(rid,detail)
    path=dict(rid=rid,kind=kind,depth=depth,step=step,expected_cached=expected,cached_detail=detail)
    return data,path

def trial(service,row,tier,depth,kind,tag):
    stem=f'{tag}.{service.model}.{service.fmt}.{tier}.d{depth}.q{row["index"]}.{kind}'
    service.phase(stem)
    control(service,stem+'.flush',tier=tier,kind='flush',depth=depth,step=0,expected_cached=0)
    service.flush()
    paths=[]
    if depth:
        assert row['cut']==8192 and 8192%depth==0
        interval=8192//depth;assert interval%256==0
        for j in range(1,depth+1):
            cut=j*interval;expected=(j-1)*interval
            data,path=request(service,dict(input_ids=row['prompt_ids'][:cut],sampling_params=dict(temperature=0,max_new_tokens=1,ignore_eos=True)),
                expected,tier,stem+f'.extend{j}','seed' if j==1 else 'extend',depth,j)
            assert data['meta_info']['completion_tokens']==1
            paths.append(path)
    expected=row['cut'] if depth else 0
    if kind=='generation':body=dict(input_ids=row['prompt_ids'],sampling_params=P['generation'])
    else:body=dict(input_ids=row['prompt_ids']+row['reference_ids'],sampling_params=dict(temperature=0,max_new_tokens=1,ignore_eos=True),
        return_logprob=True,logprob_start_len=len(row['prompt_ids'])-1,return_text_in_logprobs=False,top_logprobs_num=1)
    started=time.monotonic()
    data,path=request(service,body,expected,tier,stem+'.eval',kind,depth,depth+1,capture=bool(depth and kind=='generation'))
    paths.append(path);meta=data['meta_info']
    record=dict(tag=tag,model=service.model,format=service.fmt,tier=tier,depth=depth,index=row['index'],position=row['position'],
        kind=kind,rid=path['rid'],prompt_length=len(row['prompt_ids']),cut=row['cut'],prompt_sha256=row['prompt_sha256'],
        elapsed_s=time.monotonic()-started,paths=paths,meta=meta)
    if kind=='generation':
        assert len(data['output_ids'])==meta['completion_tokens']
        pred=answer(data['text'])
        record.update(text=data['text'],output_ids=data['output_ids'],prediction=pred,gold=canonical(row['gold']),
            correct=pred==canonical(row['gold']),truncated=meta.get('finish_reason',{}).get('type')=='length',format_error=pred is None)
    else:
        n=len(row['reference_ids']);values=meta['input_token_logprobs'][-n:]
        assert [x[1] for x in values]==row['reference_ids'],'fixed-reference token alignment'
        logs=[x[0] for x in values];assert all(x is not None and math.isfinite(x) for x in logs)
        top=meta['input_top_logprobs'][-n:]
        assert len(top)==n and all(x for x in top)
        top_ids=[x[0][1] for x in top]
        record.update(reference_logprobs=logs,reference_top1_ids=top_ids,nll=-sum(logs)/n,reference_tokens=n)
        for name in ['input_token_logprobs','input_top_logprobs','output_token_logprobs','output_top_logprobs']:
            meta.pop(name,None)
    # Directly validate actual paths and the number of effective chain restores.
    events=common.events(service.folder)
    byrid=collections.defaultdict(list)
    for e in events:
        if e.get('rid'):byrid[e['rid']].append(e)
    restored=0;stores=0;codec_loads=0;snapshots=[]
    for path in paths:
        ev=byrid[path['rid']]
        pids={e['pid'] for e in ev if e['event']=='match'};assert len(pids)==2,(path,pids)
        for pid in pids:
            pe=[e for e in ev if e['pid']==pid]
            loads=[e for e in pe if e['event']=='load_back' and e['success'] and e['mamba_requested']]
            force=[e for e in pe if e['event']=='chain_forced_eviction']
            expected_l2=bool(path['expected_cached'] and tier=='l2')
            assert bool(loads)==expected_l2,(path,pid,'actual L2',loads)
            assert bool(force)==expected_l2,(path,pid,'forced L2',force)
            decodes=[e for e in pe if e['event']=='codec_load' and e['slots']>0]
            assert bool(decodes)==bool(path['expected_cached'] and service.fmt=='int8'),(path,pid,'codec actually exercised',decodes)
            snapshots += [e['path'] for e in pe if e['event']=='state_snapshot']
        if path['expected_cached']:restored+=1
        stores+=sum(e.get('slots',0) for e in ev if e['event']=='codec_store')
        codec_loads+=sum(e.get('slots',0) for e in ev if e['event']=='codec_load')
    assert restored==depth,(restored,depth)
    assert codec_loads==(2*depth if service.fmt=='int8' else 0),(record['rid'],codec_loads,depth)
    if depth and kind=='generation':assert len(snapshots)==2,(record['rid'],snapshots)
    record.update(actual_restore_depth=restored,codec_store_slots_both_ranks=stores,codec_load_slots_both_ranks=codec_loads,
        state_snapshots=snapshots,actual_path_audited=True)
    with (service.folder/'chain_results.jsonl').open('a') as out:out.write(json.dumps(record,ensure_ascii=False)+'\n')
    return record

def run(service,pilot=False):
    import requests
    service.chain_session=requests.Session()
    rows=[json.loads(l) for l in (ROOT/f'chain_inputs_{service.model}.jsonl').read_text().splitlines()]
    if pilot:rows=rows[:P['pilot_examples']]
    depths=P['pilot_depths'] if pilot else P['depths']
    done=[];tag=service.folder.name
    try:
        for row in rows:
            # Fresh chain for every generation and every reference-scoring call.
            for tier in ['l1','l2']:
                for d in depths:
                    for kind in ['generation','scoring']:done.append(trial(service,row,tier,d,kind,tag))
            if not pilot:
                for kind in ['generation','scoring']:done.append(trial(service,row,'cold',0,kind,tag))
            common.save(service.folder/'chain_progress.json',dict(model=service.model,format=service.fmt,examples_completed=len({x['index'] for x in done}),
                examples_total=len(rows),records=len(done),last_index=row['index']))
            print('CHAIN_PROGRESS',tag,len({x['index'] for x in done}),'/',len(rows),'records',len(done),flush=True)
        assert len(done)==len(rows)*(len(depths)*4+(0 if pilot else 2))
        summary=dict(model=service.model,format=service.fmt,examples=len(rows),records=len(done),depths=depths,
            actual_paths_and_codec_counts_valid=True,selected_layer_state_snapshots=sum(len(x['state_snapshots']) for x in done),
            truncated=sum(x.get('truncated',False) for x in done),format_errors=sum(x.get('format_error',False) for x in done))
        common.save(service.folder/'chain_validation.json',summary)
    finally:service.chain_session.close()

"""Independent 002 follow-up jobs; stop on invalid paths, never on bad accuracy."""
import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
def save(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def job(stage,model,fmt,name):
    folder=ROOT/stage/name
    if (folder/'DONE').exists():return
    if folder.exists():raise RuntimeError(f'Incomplete job exists; inspect before retry: {folder}')
    cmd=[sys.executable,str(ROOT/'job.py'),stage,model,fmt,name]
    print('START',stage,name,flush=True)
    save(ROOT/'progress.json',dict(stage=stage,job=name,time=time.time()))
    with (ROOT/f'{stage}_{name}.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
    print('DONE',stage,name,flush=True)
def wait_initial():
    folder=ROOT/'pilot/gdn_bf16_r0'
    while not (folder/'DONE').exists():
        if (folder/'FAILED').exists():raise RuntimeError('Initial real-service pilot failed; inspect pilot/gdn_bf16_r0/FAILED')
        pid=json.loads((ROOT/'INITIAL_PILOT_PID.json').read_text())['pid']
        try:os.kill(pid,0)
        except ProcessLookupError:raise RuntimeError('Initial pilot process ended without DONE')
        time.sleep(2)
def gate():
    data={}
    for model in ['gdn','kda']:
        for fmt in ['bf16','int8']:
            folder=ROOT/'pilot'/f'{model}_{fmt}_r0'
            assert (folder/'DONE').exists()
            a=json.loads((folder/'allocation.json').read_text());v=json.loads((folder/'chain_validation.json').read_text())
            m=json.loads((folder/'memory_result.json').read_text())
            assert all(x['slots']==72 and x['allocated_bytes']==x['actual_storage_bytes'] for x in a['mamba'])
            assert v['records']==16 and v['actual_paths_and_codec_counts_valid']
            assert m['revisit_all_cached'] and m['l2_restore_rids']>0
            data[f'{model}_{fmt}']=dict(allocation=a,chain=v,memory=m)
    for model in ['gdn','kda']:
        a=data[f'{model}_bf16']['allocation'];b=data[f'{model}_int8']['allocation']
        assert a['kv'][0]['allocated_bytes']==b['kv'][0]['allocated_bytes']
        assert a['mamba'][0]['allocated_bytes']>b['mamba'][0]['allocated_bytes']
    save(ROOT/'PILOT_GATE_PASSED.json',dict(time=time.time(),results=data,scope='live 72-slot host allocation/fill/revisit; fixed 8K chained depths 1 and 32; both ranks actual L1/L2 and codec invocation; token alignment/finiteness; numerical changes are measured outcomes, not gate criteria'))
    print('PILOT_GATE_PASSED',flush=True)
if __name__=='__main__':
    save(ROOT/'PIPELINE_PID.json',dict(pid=os.getpid(),started=time.time()))
    try:
        wait_initial()
        job('pilot','gdn','int8','gdn_int8_r0')
        for fmt in ['bf16','int8']:job('pilot','kda',fmt,f'kda_{fmt}_r0')
        gate()
        for rep in [1,2]:
            for fmt in (['int8','bf16'] if rep==1 else ['bf16','int8']):job('memory','gdn',fmt,f'gdn_{fmt}_r{rep}')
        (ROOT/'MEMORY_ALL_DONE').touch()
        for model,info in P['models'].items():
            for rep in range(info['repeats']):
                for fmt in (['bf16','int8'] if rep%2==0 else ['int8','bf16']):
                    job('chain',model,fmt,f'{model}_{fmt}_r{rep}')
                    subprocess.run([sys.executable,str(ROOT/'analyze.py')],check=True)
        (ROOT/'ALL_RUNS_DONE').touch()
        subprocess.run([sys.executable,str(ROOT/'analyze.py'),'--final'],check=True)
    except BaseException:
        (ROOT/'PIPELINE_FAILED').write_text(traceback.format_exc());raise

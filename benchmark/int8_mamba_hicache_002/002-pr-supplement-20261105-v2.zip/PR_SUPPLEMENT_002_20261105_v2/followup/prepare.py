import hashlib,json,re,shutil,subprocess
from pathlib import Path
from transformers import AutoTokenizer
ROOT=Path(__file__).resolve().parent
OLD=Path('/mnt/sll/experiments/int8-l2-benefit-72slots-20261104')
AC=Path('/mnt/sll/experiments/int8-checkpoint-accuracy-20261103')
assert not (ROOT/'protocol.json').exists()
for f in ['prefixes.json','suffixes.json','sequences.json']:
    shutil.copy2(OLD/f,ROOT/f)
train=[json.loads(l) for l in (AC/'gsm8k_train.jsonl').read_text().splitlines()]
models={'gdn':dict(model='/mnt/sll/models/Qwen3.8-27B',tokenizer='/mnt/sll/models/Qwen3.8-27B',quantization=None,repeats=1),
        'kda':dict(model='/mnt/sll/models/Kimi-Linear-48B-A3B-Instruct-AWQ-4bit',tokenizer='/mnt/sll/sglang-0.5.22-int8-hicache-fused/fusion/kda_awq_codec_20261102/tokenizer_compat',quantization='compressed-tensors',repeats=3)}
hashes={}
for model,info in models.items():
    tok=AutoTokenizer.from_pretrained(info['tokenizer'],trust_remote_code=True,local_files_only=True)
    base=[json.loads(l) for l in (AC/f'inputs_{model}.jsonl').read_text().splitlines()][:32]
    end_ids=tok.encode('<|im_end|>',add_special_tokens=False);assert len(end_ids)==1
    text='\nAdditional reference notebook (may be irrelevant; solve the final question):\n'+'\n'.join(r['question']+' '+re.sub(r'<<.*?>>','',r['answer']) for r in train[:64])
    notes=tok.encode(text*8,add_special_tokens=False)
    out=[]
    for row in base:
        insert=row['prompt_ids'].index(end_ids[0]);added=8192-row['cut'];assert added>0 and len(notes)>added
        ids=row['prompt_ids'][:insert]+notes[:added]+row['prompt_ids'][insert:]
        assert len(ids)-8192==len(row['prompt_ids'])-row['cut']
        assert len(ids)+len(row['reference_ids'])+1024<16384
        out.append(dict(row,original_cut=row['cut'],original_prompt_ids_sha256=hashlib.sha256(json.dumps(row['prompt_ids']).encode()).hexdigest(),
                        prompt_ids=ids,cut=8192,prompt_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest()))
    path=ROOT/f'chain_inputs_{model}.jsonl';path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out))
    hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
p=json.loads((OLD/'protocol.json').read_text())
p.update(experiment='002 follow-up: equal 72 L2 slots and fixed-context chained-checkpoint precision',models=models,
    model=models['gdn']['model'],context_length=16384,chunked_prefill_size=2048,host_slots=72,
    chain_cut=8192,depths=[1,4,16,32],chain_examples=32,pilot_examples=2,pilot_depths=[1,32],
    memory_repeats=3,mem_fraction_static=.94,hicache_ratio=2,hashes=hashes,
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p['source'],text=True).strip(),
    generation=dict(temperature=0,top_k=1,top_p=1.0,max_new_tokens=1024,ignore_eos=False),
    selected_state_layers='first, middle, last (all heads/channels on those layers); save before final evaluation forward after restore',
    chain_method='For depth D, extend frozen prefix in D equal page-aligned increments summing to 8192; D-1 inter-step restores plus final evaluation restore = D. Discard warm generated tokens. Rebuild independently for task generation and teacher forcing. All conditions have identical final input tokens/length.',
    comparison_scope='Compare INT8 vs BF16 at matched depth; L2 vs L1 within format/depth. BF16 chaining and cold recompute control segmentation/background numerical effects. Small-sample task accuracy is auxiliary; primary precision metrics are fixed-reference logprob, teacher-forced top1 agreement, and selected-layer state differences. KDA repeats quantify known recomputation noise.',
    memory_scope='Both formats have exactly 72 usable host state slots; measure all actual unique host tensor storages after startup page touch and after 72-prefix fill/revisit. Keep L1 state quota 8, physical active 32, int8 checkpoint 16 and KV capacities fixed. Distinguish host payload bytes/VmLck/RSS from total-process and GPU memory.',
    kda_compat='/mnt/sll/experiments/int8-hicache-002-port-20261103/kimi_linear_awq_compat.py')
for n in ['prefixes.json','suffixes.json','sequences.json']:p['hashes'][n]=hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
(ROOT/'protocol.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
print('Prepared 32 fixed 8K-prefix cases/model; depths 1/4/16/32; 72 host slots both formats')

import argparse,json,traceback
from pathlib import Path
import common,memory,chain
p=argparse.ArgumentParser();p.add_argument('stage',choices=['pilot','memory','chain']);p.add_argument('model',choices=['gdn','kda']);p.add_argument('fmt',choices=['bf16','int8']);p.add_argument('name');a=p.parse_args()
folder=common.ROOT/a.stage/a.name
if a.stage=='chain':assert (common.ROOT/'PILOT_GATE_PASSED.json').exists(),'both model/format pilots must pass'
if (folder/'DONE').exists():raise SystemExit(0)
try:
    with common.Service(a.fmt,a.name,a.model,a.stage) as service:
        if a.stage in ['pilot','memory']:memory.run(service)
        if a.stage in ['pilot','chain']:chain.run(service,pilot=a.stage=='pilot')
    (folder/'DONE').touch()
except BaseException:
    folder.mkdir(parents=True,exist_ok=True);(folder/'FAILED').write_text(traceback.format_exc());raise

# Independent 002 follow-up: equal 72-slot memory and chained-checkpoint precision

Source: `/mnt/sll/sglang-main-int8-hicache-002-20261103`, frozen commit `15a00b66a6b388c5c795d533e4ef21a6ee92ff5e`. Every launch asserts the worktree is clean and the commit matches. No 001 rollback changes, 003 fusion, source edits, or remote PR updates. Experiment-only hooks/scripts remain here.

## Equal host-cache capacity memory experiment

Both BF16 and INT8 host state pools have exactly 72 usable slots. L1 tree state quota 8, active physical pool 32, INT8 physical checkpoint pool 16, KV L1 65536 and KV L2 131072 tokens, ratio 2 and server request limit 8 remain fixed. Model-native conv and scales are included. Host payload is measured from actual unique tensor storage bytes, checked against complete slot size; each empty unowned buffer is touched at startup, then production traffic fills all 72 slots and revisits all prefixes through real L2 recovery. No fake cached state is installed.

GDN uses BF16-weight Qwen3.8-27B; 3 independently restarted pairs. First pair runs in the pilot services. KDA's one pilot pair provides an additional architecture cross-check, reported separately, not as a three-repeat memory benchmark.

Record before/after Mamba host construction VmRSS/VmLck/HWM, service process-group RSS/PSS/locked memory at startup and after fill, plus GPU telemetry. Exact payload is the primary attributed memory result: whole-process RAM also contains model/runtime/KV allocations; GPU active/checkpoint physical layouts differ by design and total GPU memory is not claimed equal or reduced by the same percentage.

## Genuine chained state restore/store at fixed final context

32 frozen GSM8K questions/model, taken in the same fixed order from the prior full experiment. Insert the same public training-reference notebook inside the original system message so the state boundary is 8192 tokens; original few-shot examples, question, reference answer and residual suffix remain. Prompt/reference IDs and hashes are fixed before any model outputs are observed. This longer prompt is a new controlled workload, not directly comparable with the old 1319-question headline accuracy.

Depths 1/4/16/32 use 8192/D-token page-aligned extensions. For each question, start with a clean cache, process the first segment, restore and extend through later segments, then restore once more for the final evaluation. Thus D−1 intermediate restores + 1 evaluation restore = D genuine restores; the old state participates in subsequent computation before being encoded again. The extra one-token outputs from intermediate requests are discarded and never feed later input. Every format/depth/path ends on the identical 8192-token prefix and identical final question input.

Generation and fixed-reference teacher forcing independently rebuild the entire chain. Generation is greedy, budget 1024, all truncation/format errors retained. Scoring validates each reference token ID and finite logprobs, and records teacher-forced top-1 IDs. Add a freshly flushed full-recompute cold baseline (no checkpoint restoration) for both enabled formats. Compare INT8−BF16 at matched depth, L2−L1 within format/depth, BF16 chain−cold for segmentation/reuse effects, and same-path independent repeats for background variability.

GDN BF16 weights: 1 formal full run/format plus independent pilot repeat controls. KDA AWQ 4bit: 3 full independent paired runs/format, using the same previously validated, separately recorded model/tokenizer compatibility overlay. It is not part of 002. TP2, client concurrency 1, active state BF16, prefill chunk 2048, context 16384, original overlap. KV dtype GDN FP8 E4M3; KDA auto. Models retain original text/MRoPE path. Only unused GDN visual weights sit on CPU, with no timed text-weight offload or vision inference; skip default image warmup and perform token-only warmup.

Every real request asserts its expected reusable prefix and L1/L2 source. L2 precision trials drain real backups and invoke production eviction before every continuation; this intentional synchronization/forced eviction is for correctness and is not a performance measurement. Direct codec store/load counters validate that quantization/dequantization actually runs at every expected INT8 restore on both ranks. Do not substitute repeatedly reloading an unchanged checkpoint for genuine chained extension.

At the final restore, capture BF16 active state from the first/middle/last state layers (all heads/channels of those layers), before subsequent computation. This records accumulation at a common context boundary with manageable storage. These are sampled-layer relative errors, not a full-state theoretical bound. Full-model fixed-reference logprob/top-1/task outputs provide the other precision evidence.

32-question task accuracy is auxiliary. Do not claim statistical equivalence or no task degradation based on this small test. KDA repeated computations can vary; compare the quantization signal against its measured same-path background. A flat sampled-state curve alone does not prove full-model error never accumulates.

## Gates and durable execution

Pilots: 2 questions/model, depths 1 and 32, both checkpoint formats and L1/L2, plus actual 72-slot fill/revisit. Only path/alignment/finiteness/codec invocation/resource validity gate admission; accuracy changes and large numerical errors remain outcomes, not reasons to change protocol/drop questions.

`pipeline.py` waits for the initial manually launched GDN BF16 pilot, runs remaining pilots, then the remaining memory pairs and all formal chain jobs. Failure stops later work and writes PIPELINE_FAILED. `progress.py` reports compact status. Partial/final analysis is automatic; only after both experiment families finish does the pipeline produce RESULTS.json, REPORT_ZH.md, figures and ARTIFACTS_READY. No step-by-step user prompting is required.

Preflight harness metadata failures are retained under diagnostic folders and excluded from formal results. The common Service and source remain auditable in each launch.json; model/production code is never patched to make a test pass.

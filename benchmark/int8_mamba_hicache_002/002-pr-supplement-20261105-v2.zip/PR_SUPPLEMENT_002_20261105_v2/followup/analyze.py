"""Consolidate equal-capacity host memory and fixed-length chained precision."""
import argparse,collections,json,math,statistics
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
torch.set_num_threads(4)

def avg(x):return float(np.mean(x))
def memory_results(final):
    result={}
    for model,repeats in [('gdn',3),('kda',1)]:
        pairs=[]
        for rep in range(repeats):
            data={}
            for fmt in ['bf16','int8']:
                folder=ROOT/('pilot' if rep==0 else 'memory')/f'{model}_{fmt}_r{rep}'
                if not (folder/'DONE').exists():continue
                v=json.loads((folder/'memory_result.json').read_text())
                assert v['slots']==72 and v['revisit_all_cached']
                for r in v['allocations']:assert r['actual_storage_bytes']==r['allocated_bytes']==72*r['bytes_per_slot']
                data[fmt]=v
            if len(data)!=2:continue
            a=data['bf16']['allocations'][0]['actual_storage_bytes'];b=data['int8']['allocations'][0]['actual_storage_bytes']
            pairs.append(dict(repeat=rep,bf16=data['bf16'],int8=data['int8'],saved_bytes_per_rank=a-b,host_payload_reduction=1-b/a))
        if final:assert len(pairs)==repeats
        if pairs:result[model]=dict(paired_repeats=len(pairs),pairs=pairs,
            bf16_payload_GiB=avg([x['bf16']['allocations'][0]['actual_storage_bytes']/2**30 for x in pairs]),
            int8_payload_GiB=avg([x['int8']['allocations'][0]['actual_storage_bytes']/2**30 for x in pairs]),
            saved_GiB_per_rank=avg([x['saved_bytes_per_rank']/2**30 for x in pairs]),
            payload_reduction_pct=avg([x['host_payload_reduction']*100 for x in pairs]))
    return result

def read_model(model):
    result={};folders=[]
    for rep in range(P['models'][model]['repeats']):
        data={}
        for fmt in ['bf16','int8']:
            folder=ROOT/'chain'/f'{model}_{fmt}_r{rep}'
            if not (folder/'DONE').exists():continue
            rows=[json.loads(l) for l in (folder/'chain_results.jsonl').read_text().splitlines()]
            assert len(rows)==32*18
            for r in rows:
                key=(r['index'],fmt,r['tier'],r['depth'],r['kind'])
                assert key not in data
                assert r['actual_restore_depth']==r['depth'] and r['actual_path_audited']
                data[key]=r
            folders.append(folder.name)
        if len(data)==32*18*2:result[rep]=data
    return result,folders

def state_pair(a,b):
    left={};right={}
    for dest,record in [(left,a),(right,b)]:
        for f in record['state_snapshots']:
            tensor=torch.load(f,map_location='cpu',weights_only=True);dest[tensor['tp_rank']]=tensor
    assert set(left)==set(right)=={0,1}
    rows=[]
    for rank in [0,1]:
        a=left[rank];b=right[rank];assert a['layers']==b['layers']
        ref=a['temporal'].float();test=b['temporal'].float()
        assert torch.isfinite(ref).all() and torch.isfinite(test).all()
        difference=test-ref;norm=torch.linalg.vector_norm(ref).item();assert norm>0
        rows.append(dict(rank=rank,relative_frobenius=torch.linalg.vector_norm(difference).item()/norm,
            max_abs_error=difference.abs().max().item(),conv_equal=all(torch.equal(x,y) for x,y in zip(a['conv'],b['conv']))))
    return rows

def compare(A,B,sa,sb,ids,states=True):
    logs=[];tops=[];deltas=[];nll=[];same=0;states_out=[];flips=[]
    for index in ids:
        ga=A[(index,*sa,'generation')];gb=B[(index,*sb,'generation')]
        a=A[(index,*sa,'scoring')];b=B[(index,*sb,'scoring')]
        assert ga['prompt_sha256']==gb['prompt_sha256'] and len(a['reference_logprobs'])==len(b['reference_logprobs'])
        diff=np.asarray(b['reference_logprobs'])-np.asarray(a['reference_logprobs']);logs.extend(diff.tolist())
        tops.extend([x==y for x,y in zip(a['reference_top1_ids'],b['reference_top1_ids'])]);nll.append(b['nll']-a['nll'])
        deltas.append(int(gb['correct'])-int(ga['correct']));same+=int(ga['output_ids']==gb['output_ids'])
        if ga['correct']!=gb['correct']:flips.append(dict(index=index,baseline_correct=ga['correct'],candidate_correct=gb['correct'],baseline_answer=ga['prediction'],candidate_answer=gb['prediction']))
        if states and sa[2] and sb[2]:states_out.extend(dict(index=index,**x) for x in state_pair(ga,gb))
    diff=np.asarray(logs);absolute=abs(diff)
    return dict(n=len(ids),baseline=list(sa),candidate=list(sb),accuracy_delta=sum(deltas)/len(ids),answer_flips=flips,
        output_sequences_equal=same,reference_tokens=len(diff),mean_abs_delta_logprob=float(absolute.mean()),
        max_abs_delta_logprob=float(absolute.max()),p99_abs_delta_logprob=float(np.quantile(absolute,.99)),
        token_weighted_delta_nll=float(-diff.mean()),teacher_forced_top1_agreement=avg(tops),
        sampled_state_relative_frobenius_mean=avg([x['relative_frobenius'] for x in states_out]) if states_out else None,
        sampled_state_relative_frobenius_max=max([x['relative_frobenius'] for x in states_out]) if states_out else None,
        sampled_state_rows=states_out)

def chain_results(final):
    results={}
    for model,info in P['models'].items():
        repetitions,folders=read_model(model)
        if final:assert len(repetitions)==info['repeats'],(model,len(repetitions))
        if not repetitions:continue
        ids=sorted({k[0] for data in repetitions.values() for k in data})
        assert len(ids)==32
        conditions={};comparisons={};noise={};repeat_controls={}
        for rep,data in repetitions.items():
            for fmt in ['bf16','int8']:
                for tier,depths in [('l1',P['depths']),('l2',P['depths']),('cold',[0])]:
                    for depth in depths:
                        label=f'{fmt}_{tier}_d{depth}'
                        gen=[data[(i,fmt,tier,depth,'generation')] for i in ids]
                        score=[data[(i,fmt,tier,depth,'scoring')] for i in ids]
                        item=dict(repeat=rep,n=32,correct=sum(x['correct'] for x in gen),accuracy=sum(x['correct'] for x in gen)/32,
                            truncated=sum(x['truncated'] for x in gen),format_errors=sum(x['format_error'] for x in gen),
                            reference_tokens=sum(x['reference_tokens'] for x in score),token_weighted_nll=sum(x['nll']*x['reference_tokens'] for x in score)/sum(x['reference_tokens'] for x in score))
                        conditions.setdefault(label,[]).append(item)
            for depth in P['depths']:
                for sa,sb in [(('bf16','l1',depth),('int8','l1',depth)),(('bf16','l2',depth),('int8','l2',depth)),
                              (('bf16','l1',depth),('bf16','l2',depth)),(('int8','l1',depth),('int8','l2',depth)),
                              (('bf16','cold',0),('bf16','l1',depth))]:
                    label='_'.join(map(str,sb))+'_minus_'+'_'.join(map(str,sa))
                    item=compare(data,data,sa,sb,ids,states=sa[2]>0);item['repeat']=rep
                    comparisons.setdefault(label,[]).append(item)
            cold=compare(data,data,('bf16','cold',0),('int8','cold',0),ids,states=False);cold['repeat']=rep
            comparisons.setdefault('int8_cold_minus_bf16_cold',[]).append(cold)
        if 0 in repetitions:
            for rep,data in repetitions.items():
                if rep==0:continue
                for fmt in ['bf16','int8']:
                    for tier in ['l1','l2']:
                        for depth in P['depths']:
                            label=f'{fmt}_{tier}_{depth}'
                            item=compare(repetitions[0],data,(fmt,tier,depth),(fmt,tier,depth),ids)
                            item['candidate_repeat']=rep;noise.setdefault(label,[]).append(item)
        for fmt in ['bf16','int8']:
            folder=ROOT/'pilot'/f'{model}_{fmt}_r0'
            pilot=[json.loads(l) for l in (folder/'chain_results.jsonl').read_text().splitlines()]
            pilot_map={(r['index'],fmt,r['tier'],r['depth'],r['kind']):r for r in pilot}
            ids_small=sorted({r['index'] for r in pilot})
            if 0 in repetitions:
                repeat_controls[fmt]={f'{tier}_d{d}':compare(pilot_map,repetitions[0],(fmt,tier,d),(fmt,tier,d),ids_small,states=False) for tier in ['l1','l2'] for d in P['pilot_depths']}
        results[model]=dict(examples=32,paired_repeats=len(repetitions),completed_runs=folders,conditions=conditions,
            comparisons=comparisons,same_path_repeat_noise=noise,repeatability_vs_pilot=repeat_controls)
    return results

def report(result):
    lines=['# 002 补充实验：相同 72 槽内存与连续 checkpoint 精度','',
      f"源码为独立 002 `{P['source_commit']}`，生产工作树保持干净，001/003 均未混入。所有模型沿用原 eager codec。",'',
      '## 相同 72 槽的实测主机内存','',
      '两组 L1 缓存配额均为 8，active 物理池为 32，KV L1/L2 容量相同；INT8 使用独立的 16 槽物理 checkpoint 池。两组 Mamba host pool 均恰好 72 个可用槽位，启动时触及全部未使用 buffer 页，再实际填满并回迁 72 个不同 1K 前缀。', '',
      '| 模型 | 独立配对次数 | BF16 host payload / rank | INT8 host payload / rank | 节省 / rank | 减少 |','|---|---:|---:|---:|---:|---:|']
    for model,x in result['memory'].items():lines.append(f"| {model} | {x['paired_repeats']} | {x['bf16_payload_GiB']:.6f} GiB | {x['int8_payload_GiB']:.6f} GiB | {x['saved_GiB_per_rank']:.6f} GiB | {x['payload_reduction_pct']:.3f}% |")
    lines+=['','Payload 从实际唯一 tensor storage 统计，包含 temporal、conv 和 scale；同时核对完整状态大小估算。每个 rank 的前后 VmRSS/VmLck、服务进程组 RSS/PSS/锁页数，以及 GPU 采样单独保存。上述百分比仅描述 Mamba L2 payload，不能解释为整进程 RAM 或 GPU 显存减少同样比例。GDN 做三轮配对；KDA 的单轮来自路径预跑，作为补充而非三轮内存基准。','',
      '## 固定 8K 最终上下文的链式精度','',
      '每个模型使用固定 32 道 GSM8K 测试题，在原 8-shot 提示的 system 消息内加入固定训练集参考笔记，使 checkpoint 边界统一为 8192 tokens；所有深度/格式/层级使用完全相同的最终 prompt 与参考答案 token。不能直接与此前短提示下的 1319 题准确率比较。', '',
      '深度为 1/4/16/32。每一轮恢复前一个状态，继续计算固定的下一段 token，再缓存新状态；最终评估再恢复最后一个状态。扩展过程中生成的 1 token 不进入下一次输入，确保比较输入一致。D−1 次中间恢复加最终 1 次，构成 D 次有效串联恢复。真实 codec store/load 次数、双 rank H2D/路径和 cached token 长度全部核验。', '',
      '生成与参考答案打分分别清空缓存、独立构建链。L2 组在每次继续前通过生产 backup-completion/eviction 路径制造受控回迁，并等待传输；这是正确性实验，不计恢复性能。另做无缓存完整重算基线，用于区分 BF16 分段执行/复制本身的数值影响。', '',
      'GDN 使用未量化 BF16 权重、1 次正式完整运行，另有独立 pilot 的重复对照；KDA 使用原 AWQ 4bit 及相同独立兼容层，正式运行 3 次以测量已知复算背景。两者均 TP2、客户端并发 1、原 overlap 设置和贪心生成，上限 1024 tokens，所有截断/格式失败均保留。','',
      '下表比较每个深度下的 INT8 与 BF16 checkpoint。数值为各重复统计的均值；KDA 同题重复不作为额外独立题目。状态指标只覆盖第一/中间/最后三个 state 层的全部 heads/channels，在最终恢复后、后续 forward 前采样，不是全状态误差上界。','',
      '| 模型 | 恢复路径 | 有效恢复次数 | BF16 / INT8 正确数（每次32题，跨重复均值） | mean |Δlogprob| | 参考 token top-1 一致率 | sampled state 相对误差均值 | L2 vs L1 的 mean |Δlogprob|（同格式） |',
      '|---|---|---:|---|---:|---:|---:|---|']
    # Escape vertical bars in a table label to keep Markdown column counts valid.
    lines[-2]='| 模型 | 恢复路径 | 有效恢复次数 | BF16 / INT8 正确数（每次32题，跨重复均值） | 平均绝对 Δlogprob | 参考 token top-1 一致率 | sampled state 相对误差均值 | 同格式 L2/L1 平均绝对 Δlogprob |'
    for model,v in result['chain'].items():
        for tier in ['l1','l2']:
            for d in P['depths']:
                c=v['comparisons'][f'int8_{tier}_{d}_minus_bf16_{tier}_{d}']
                a=v['conditions'][f'bf16_{tier}_d{d}'];b=v['conditions'][f'int8_{tier}_d{d}']
                l2=[avg([x['mean_abs_delta_logprob'] for x in v['comparisons'][f'{fmt}_l2_{d}_minus_{fmt}_l1_{d}']]) for fmt in ['bf16','int8']]
                lines.append(f"| {model} | {tier} | {d} | {avg([x['correct'] for x in a]):.2f} / {avg([x['correct'] for x in b]):.2f} | {avg([x['mean_abs_delta_logprob'] for x in c]):.8f} | {avg([x['teacher_forced_top1_agreement'] for x in c])*100:.3f}% | {avg([x['sampled_state_relative_frobenius_mean'] for x in c]):.8f} | {l2[0]:.8f} / {l2[1]:.8f} |")
    lines+=['','## 重复性与解释范围','',
      '同深度 INT8−BF16 是主要量化对照；同格式 L2−L1 用于检查搬运新增影响；BF16 chain−cold 用于检查分段/复用本身的误差。KDA 另保存相同格式、路径、深度在独立运行间的 logprob/top-1/state 噪声，避免把背景波动解释成误差累积或 L2 损伤。','',
      '32 题任务准确率只作辅助观察，不能证明量化无损、统计等价或所有长对话无退化。不能仅凭 state 相对误差平稳就断言全模型误差有理论上界；也不能把不同深度的变化全部归因于量化，因为分段长度随深度改变，BF16 对照同样受影响。','',
      '原始数据、每题翻转和全部重复对照见 RESULTS.json 与各服务 chain_results.jsonl / states / audit。之前的完整 1319 题精度测试，以及72→136槽的三轮性能实验保持独立；本轮不改写此前结论。','',
      '相关既有报告：','',
      '- `/mnt/sll/experiments/int8-checkpoint-accuracy-bf16weights-20261103/REPORT_ZH.md`','- `/mnt/sll/experiments/int8-checkpoint-accuracy-20261103/REPORT_ZH.md`','- `/mnt/sll/experiments/int8-l2-benefit-72slots-20261104/REPORT_ZH.md`']
    (ROOT/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n')

def analyze(final):
    result=dict(final=final,source_commit=P['source_commit'],protocol=P,memory=memory_results(final),chain=chain_results(final))
    target=ROOT/('RESULTS.json' if final else 'PARTIAL_RESULTS.json');target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print('ANALYSIS',final,'memory',list(result['memory']),'chain',list(result['chain']),flush=True)
    if final:
        report(result)
        import subprocess,sys
        subprocess.run([sys.executable,str(ROOT/'plot.py')],check=True)
        (ROOT/'ARTIFACTS_READY').touch()
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--final',action='store_true');args=a.parse_args();analyze(args.final)

"""Equal-budget BF16/INT8 L2 real-service experiment (002 only)."""
import collections,concurrent.futures as cf,hashlib,json,math,os,signal,subprocess,sys,threading,time,traceback
from pathlib import Path
import requests
import numpy as np
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
SOURCE=Path(P['source']);DEPS=Path('/mnt/sll/experiments/codec-main-20261102/deps')
URL='http://127.0.0.1:18093'
PREFIX=json.loads((ROOT/'prefixes.json').read_text());SUFFIX=json.loads((ROOT/'suffixes.json').read_text());SEQUENCES=json.loads((ROOT/'sequences.json').read_text())
def save(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n');tmp.replace(path)
def events(folder):
    return [json.loads(l) for f in (folder/'audit').glob('*.jsonl') for l in f.read_text().splitlines()]
class Service:
    def __init__(self,fmt,name,model='gdn',stage='memory'):
        self.fmt=fmt;self.model=model;self.stage=stage
        self.prefixes=PREFIX if model=='gdn' else json.loads((ROOT/'prefixes_kda.json').read_text())
        self.suffixes=SUFFIX if model=='gdn' else json.loads((ROOT/'suffixes_kda.json').read_text())
        self.folder=ROOT/stage/name;self.folder.mkdir(parents=True,exist_ok=False)
        self.phase_name='startup';self.counter=0;self.lock=threading.Lock();self.active=0;self.peak=0
        self.phase('startup');self.stop_monitor=threading.Event()
        args=[sys.executable,'-m','sglang.launch_server','--model-path',P['models'][model]['model'],'--tokenizer-path',P['models'][model]['tokenizer'],
            '--trust-remote-code','--host','127.0.0.1','--port','18093','--tp-size','2','--dtype','bfloat16',
            '--attention-backend','flashinfer','--linear-attn-decode-backend','triton','--kv-cache-dtype','fp8_e4m3' if model=='gdn' else 'auto',
            '--cuda-graph-backend-prefill','disabled','--cuda-graph-max-bs-decode','8','--max-running-requests','8',
            '--context-length',str(P['context_length']),'--chunked-prefill-size',str(P['chunked_prefill_size']),
            '--max-prefill-tokens','8192','--max-total-tokens',str(P['kv_l1_tokens']),'--page-size','256',
            '--mem-fraction-static',str(P['mem_fraction_static'] if model=='gdn' else .85),'--mamba-ssm-dtype','bfloat16',
            '--mamba-radix-cache-strategy','extra_buffer_lazy','--max-mamba-cache-size','32',
            '--enable-hierarchical-cache','--hicache-ratio',str(P['hicache_ratio']),'--hicache-io-backend','kernel',
            '--hicache-mem-layout','page_first','--hicache-write-policy','write_through',
            '--enable-cache-report','--random-seed','20261103','--stream-interval','1','--skip-server-warmup']
        if model=='kda':args+=['--quantization','compressed-tensors']
        if fmt=='int8':args+=['--enable-int8-mamba-checkpoint','--int8-mamba-ckpt-size','16']
        if P['language_model_only']:args+=['--json-model-override-args',json.dumps({'language_model_only':True})]
        env=os.environ.copy()
        for key in list(env):
            if key.startswith(('CHECKPOINT_ACCURACY_','INT8_HICACHE_','L2_BENEFIT_','L2_FOLLOWUP_','L2_HOST_')):env.pop(key)
        env.update(PYTHONPATH=f'{SOURCE/"python"}:{ROOT/"audit"}:{DEPS}',CUDA_VISIBLE_DEVICES='0,1',
            SGLANG_RUST_BUILD_MODE='auto',SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN='1',L2_BENEFIT_RUN=str(self.folder),
            L2_BENEFIT_L1_SLOTS=str(P['l1_cache_slots']),
            L2_BENEFIT_KV_TOKENS=str(P['kv_l2_tokens']),L2_FOLLOWUP_MODEL=model,L2_FOLLOWUP_STAGE=stage,L2_HOST_SLOTS=str(P['host_slots']))
        if model=='kda':env['L2_FOLLOWUP_KDA_COMPAT']=P['kda_compat']
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==P['source_commit']
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
        for file,digest in P['hashes'].items():assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==digest,file
        save(self.folder/'launch.json',dict(args=args,source_commit=P['source_commit'],
            env={k:v for k,v in env.items() if k.startswith(('L2_BENEFIT_','L2_FOLLOWUP_','L2_HOST_','PYTHONPATH','CUDA_VISIBLE','SGLANG_RUST','SGLANG_ALLOW'))},
            hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['common.py','job.py','chain.py','memory.py','protocol.json','audit/sitecustomize.py']}))
        self.log=(self.folder/'server.log').open('w')
        self.proc=subprocess.Popen(args,cwd=SOURCE,env=env,stdout=self.log,stderr=subprocess.STDOUT,start_new_session=True)
        save(self.folder/'PID.json',dict(pid=self.proc.pid))
        self.monitor=threading.Thread(target=self.telemetry,daemon=True);self.monitor.start()
    def phase(self,name):
        self.phase_name=name;(self.folder/'phase.txt').write_text(name)
    def telemetry(self):
        while not self.stop_monitor.wait(2):
            try:
                s=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu,power.draw,clocks.sm,temperature.gpu','--format=csv,noheader,nounits'],text=True,timeout=10)
                with (self.folder/'gpu.jsonl').open('a') as out:out.write(json.dumps(dict(time=time.time(),phase=self.phase_name,raw=s))+'\n')
            except Exception:pass
    def __enter__(self):
        try:
            deadline=time.monotonic()+1200
            while True:
                if self.proc.poll() is not None:raise RuntimeError(f'server exit {self.proc.returncode}: {self.folder}')
                try:
                    if requests.get(URL+'/health',timeout=1).ok:break
                except requests.RequestException:pass
                assert time.monotonic()<deadline,'startup timeout';time.sleep(1)
            info=requests.get(URL+'/get_server_info',timeout=60).json();save(self.folder/'server_info.json',info)
            assert info['quantization']==P['models'][self.model]['quantization'] and info['dtype']=='bfloat16'
            assert info['max_total_num_tokens']==P['kv_l1_tokens']
            assert info['hicache_ratio']==2 and info['max_running_requests']==8
            ev=events(self.folder)
            m=[e for e in ev if e['event']=='mamba_budget'];k=[e for e in ev if e['event']=='kv_budget']
            assert len(m)==len(k)==2,(m,k)
            assert len({e['slots'] for e in m})==1
            assert all(e['slots']==72 and e['allocated_bytes']==72*e['bytes_per_slot'] and e['actual_storage_bytes']==e['allocated_bytes'] and e['l1_cache_slot_quota']==P['l1_cache_slots'] for e in m)
            assert all(e['tokens']==P['kv_l2_tokens'] for e in k)
            runtime=[e for e in ev if e['event']=='runtime_model']
            assert len(runtime)==2
            if self.model=='gdn':assert all(not e['language_model_only'] and e['visual_parameter_device']=='cpu' and e['is_mrope_enabled'] for e in runtime)
            save(self.folder/'allocation.json',dict(mamba=m,kv=k,runtime_model=runtime,l1_cache_slot_quota=P['l1_cache_slots']))
            return self
        except BaseException:self.close();raise
    def close(self):
        if self.proc.poll() is None:
            os.killpg(self.proc.pid,signal.SIGTERM)
            try:self.proc.wait(timeout=45)
            except subprocess.TimeoutExpired:os.killpg(self.proc.pid,signal.SIGKILL);self.proc.wait()
        self.stop_monitor.set();self.monitor.join(12);self.log.close()
    def __exit__(self,*a):self.close()
    def flush(self):
        r=requests.post(URL+'/flush_cache?timeout=30',timeout=90);r.raise_for_status();assert r.text.startswith('Cache flushed.')
    def query(self,length,key,index,n=32,session=None):
        client=session or requests.Session()
        ids=self.prefixes[str(length)][key]+self.suffixes[index%len(self.suffixes)]
        with self.lock:
            self.counter+=1;rid=f'{self.folder.name}:{self.phase_name}:k{key}:i{index}:r{self.counter}'
            self.active+=1;self.peak=max(self.peak,self.active)
        start=time.perf_counter();first=None;last=None
        try:
            with client.post(URL+'/generate',json=dict(rid=rid,input_ids=ids,stream=True,
                sampling_params=dict(temperature=0,top_k=1,max_new_tokens=n,ignore_eos=True)),stream=True,timeout=(15,300)) as response:
                response.raise_for_status()
                for raw in response.iter_lines(chunk_size=1):
                    if not raw.startswith(b'data: '):continue
                    data=raw[6:]
                    if data==b'[DONE]':break
                    item=json.loads(data)
                    assert 'error' not in item,item
                    if first is None and (item.get('output_ids') or item.get('text')):first=time.perf_counter()
                    last=item
            finish=time.perf_counter();assert last is not None and first is not None
            meta=last['meta_info'];assert meta['completion_tokens']==n,meta
            assert meta.get('num_retractions',0)==0,meta
            cached=meta.get('cached_tokens',0);assert 0<=cached<=length,(length,cached,meta)
            return dict(rid=rid,key=key,index=index,prefix_length=length,prompt_tokens=len(ids),
                ttft_s=first-start,latency_s=finish-start,begin=start,end=finish,cached_tokens=cached,
                recomputed_prefix_tokens=length-cached,computed_input_tokens=len(ids)-cached,
                output_ids=last.get('output_ids'),output_tokens=n,meta=meta)
        finally:
            with self.lock:self.active-=1
            if session is None:client.close()
    def window(self,config,keys,name):
        self.phase(name);start=time.perf_counter();c=config['concurrency'];barrier=threading.Barrier(c+1)
        # Each worker receives a frozen key subsequence: groups preserve exactly
        # the same per-worker stream, though scheduler interleaving can differ.
        def worker(w):
            rows=[]
            with requests.Session() as session:
                barrier.wait()
                for i in range(w,len(keys),c):rows.append(self.query(config['length'],keys[i],i,session=session))
            return rows
        with cf.ThreadPoolExecutor(c) as pool:
            fs=[pool.submit(worker,w) for w in range(c)]
            start=time.perf_counter();barrier.wait()
            rows=sorted([r for f in fs for r in f.result()],key=lambda r:r['index'])
            elapsed=time.perf_counter()-start
        assert len(rows)==len(keys)
        assert [r['index'] for r in rows]==list(range(len(keys)))
        assert [r['key'] for r in rows]==list(keys)
        return summarize(config,rows,elapsed,name),rows
    def seed(self,config):
        self.phase('seed_'+config['name']);self.flush()
        for k in range(config['working_set']):self.query(config['length'],k,7000+k,n=1)

def summarize(config,rows,elapsed,name):
    ttft=np.array([r['ttft_s'] for r in rows]);cached=sum(r['cached_tokens'] for r in rows)
    prefix=config['length'];n=len(rows)
    return dict(**config,phase=name,n=n,elapsed_s=elapsed,requests_per_s=n/elapsed,
        output_tokens_per_s=sum(r['output_tokens'] for r in rows)/elapsed,
        logical_input_tokens_per_s=sum(r['prompt_tokens'] for r in rows)/elapsed,
        ttft_mean_s=float(ttft.mean()),ttft_p50_s=float(np.median(ttft)),ttft_p95_s=float(np.quantile(ttft,.95)),
        mean_latency_s=sum(r['latency_s'] for r in rows)/n,
        full_prefix_reuse_rate=sum(r['cached_tokens']==prefix for r in rows)/n,
        cache_miss_rate=sum(r['cached_tokens']==0 for r in rows)/n,
        partial_prefix_reuse_rate=sum(0<r['cached_tokens']<prefix for r in rows)/n,
        prefix_tokens_recomputed=sum(r['recomputed_prefix_tokens'] for r in rows),
        mean_prefix_tokens_recomputed=sum(r['recomputed_prefix_tokens'] for r in rows)/n,
        actual_input_tokens_computed=sum(r['computed_input_tokens'] for r in rows),
        cached_prefix_tokens=cached,retractions=sum(r['meta'].get('num_retractions',0) for r in rows),
        cached_detail_counts=dict(collections.Counter(json.dumps(r['meta'].get('cached_tokens_details',{}),sort_keys=True) for r in rows)))

def audit_window(folder,name,rows):
    ev=[e for e in events(folder) if e['phase']==name]
    rids={r['rid'] for r in rows}
    exact=[e for e in events(folder) if e.get('rid') in rids]
    match={}
    for e in exact:
        if e['event']=='match':match.setdefault(e['rid'],[]).append(e)
    assert all(r['rid'] in match for r in rows),'missing match audit'
    restored={e['rid'] for e in exact if e['event']=='load_back' and e['success'] and e['mamba_requested']}
    l1=0;l2=0;miss=0
    for r in rows:
        if r['cached_tokens']>0:
            if r['rid'] in restored:l2+=1
            else:l1+=1
        else:miss+=1
    pids={e['pid'] for e in exact if e['event']=='match'};assert len(pids)==2
    for rid in restored:
        restored_pids={e['pid'] for e in exact if e.get('rid')==rid and e['event']=='load_back' and e['success'] and e['mamba_requested']}
        assert restored_pids==pids,('asymmetric Mamba restore',rid,restored_pids,pids)
    # Count one rank's model work, never sum replicated TP token counts.
    per_rank={}
    for pid in pids:
        tokens=sum(e.get('tokens') or 0 for e in ev if e['event']=='prefill' and e['pid']==pid)
        per_rank[str(pid)]=tokens
    expected_tokens=sum(r['computed_input_tokens'] for r in rows)
    assert all(v==expected_tokens for v in per_rank.values()),('actual prefill mismatch',name,per_rank,expected_tokens)
    return dict(mamba_l1_hits=l1,mamba_l2_restores=l2,state_misses=miss,
        l1_hit_rate=l1/len(rows),l2_restore_rate=l2/len(rows),state_miss_rate=miss/len(rows),
        audited_ranks=2,prefill_tokens_per_rank=per_rank,
        d2h_bytes_per_rank={str(pid):sum(e['bytes'] for e in ev if e['pid']==pid and e['event']=='d2h') for pid in pids},
        h2d_bytes_per_rank={str(pid):sum(e['bytes'] for e in ev if e['pid']==pid and e['event']=='h2d') for pid in pids},
        quota_admission_skips=sum(e['event']=='quota_admission_skip' for e in exact),
        quota_load_deferrals=sum(e['event']=='quota_load_deferred' for e in exact))

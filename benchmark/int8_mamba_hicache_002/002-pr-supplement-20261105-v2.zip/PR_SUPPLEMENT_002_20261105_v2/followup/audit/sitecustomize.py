"""Experiment-only equal resource budgets and common L1 cache admission quota.

No tensor/codec changes, injected cache hits, synchronous transfer checks, or
forced eviction of a named target. Quota pressure uses production LRU eviction.
"""
import os
if os.environ.get('L2_BENEFIT_RUN'):
    import functools,json,time,inspect,importlib.abc,importlib.util,sys
    compat=os.environ.get('L2_FOLLOWUP_KDA_COMPAT')
    if compat:
        class KimiCompatibility(importlib.abc.MetaPathFinder):
            def find_spec(self,fullname,path=None,target=None):
                if fullname=='sglang.srt.models.kimi_linear':return importlib.util.spec_from_file_location(fullname,compat)
        sys.meta_path.insert(0,KimiCompatibility())
    from pathlib import Path
    import torch
    from sglang.srt.mem_cache.pool_host.mamba import MambaPoolHost
    from sglang.srt.mem_cache.pool_host.mha import MHATokenToKVPoolHost
    from sglang.srt.mem_cache.unified_radix_cache import UnifiedRadixCache
    from sglang.srt.mem_cache.unified_cache.components.mamba import MambaComponent
    from sglang.srt.mem_cache.base_prefix_cache import EvictParams,MatchPrefixParams
    from sglang.srt.mem_cache.radix_cache import RadixKey
    from sglang.srt.mem_cache.unified_cache.component_type import ComponentType
    from sglang.srt.model_executor.model_runner import ModelRunner

    root=Path(os.environ['L2_BENEFIT_RUN']);(root/'audit').mkdir(parents=True,exist_ok=True)
    quota=int(os.environ.get('L2_BENEFIT_L1_SLOTS','8'))
    host_slots=int(os.environ.get('L2_HOST_SLOTS','72'))
    model_name=os.environ.get('L2_FOLLOWUP_MODEL','gdn')
    followup_stage=os.environ.get('L2_FOLLOWUP_STAGE','memory')
    def proc_memory():
        result={}
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith(('VmRSS:','VmLck:','VmHWM:')):
                k,v,*_=line.split();result[k.rstrip(':')]=int(v)*1024
        return result
    def command():
        try:return json.loads((root/'command.json').read_text())
        except (OSError,ValueError):return {}
    kv_tokens=int(os.environ.get('L2_BENEFIT_KV_TOKENS','262144'))
    stream=(root/'audit'/f'{os.getpid()}.jsonl').open('a',buffering=1)
    phase_path=root/'phase.txt';phase='startup';last_phase_check=0.
    def emit(event,**kw):
        global phase,last_phase_check
        now=phase_path.stat().st_mtime_ns if phase_path.exists() else 0
        if now!=last_phase_check:
            try:phase=phase_path.read_text().strip()
            except OSError:pass
            last_phase_check=now
        kw.setdefault('rid',command().get('rid'))
        stream.write(json.dumps(dict(event=event,time=time.time(),pid=os.getpid(),phase=phase,**kw),separators=(',',':'))+'\n')

    original_host=MambaPoolHost.__init__
    @functools.wraps(original_host)
    def host(self,buffer_info,host_to_device_ratio,host_size,**kwargs):
        b=buffer_info
        per_slot=b.temporal.numel()//b.temporal.shape[1]*b.temporal.element_size()
        per_slot+=sum(c.numel()//c.shape[1]*c.element_size() for c in b.conv)
        per_slot+=sum(c.numel()//c.shape[0]*c.element_size() for c in b.extra_checkpoint_buffers)
        slots=host_slots
        own_budget=slots*per_slot
        before=proc_memory()
        assert slots>quota,(slots,quota)
        # Mamba host adds one slot after flooring host_size / size_per_token.
        original_host(self,buffer_info,host_to_device_ratio,(slots-.25)*per_slot/1e9,**kwargs)
        assert self.size==slots and self.size_per_token==per_slot
        buffers=[self.temporal_buffer,*self.conv_buffer,*self.slot_state_buffers]
        storages={b.untyped_storage().data_ptr():b.untyped_storage().nbytes() for b in buffers}
        # Touch empty, unowned host buffers before any production cache backup.
        for tensor in buffers:tensor.zero_()
        actual_bytes=sum(storages.values());assert actual_bytes==slots*per_slot
        emit('mamba_budget',budget_bytes=own_budget,allocated_bytes=self.size*per_slot,actual_storage_bytes=actual_bytes,
             temporal_bytes=self.temporal_buffer.numel()*self.temporal_buffer.element_size(),conv_bytes=sum(b.numel()*b.element_size() for b in self.conv_buffer),scale_bytes=sum(b.numel()*b.element_size() for b in self.slot_state_buffers),proc_before=before,proc_after=proc_memory(),
             bytes_per_slot=per_slot,slots=self.size,unused_budget_bytes=own_budget-self.size*per_slot,
             temporal_dtype=str(b.temporal.dtype),l1_cache_slot_quota=quota)
    MambaPoolHost.__init__=host

    original_kv=MHATokenToKVPoolHost.__init__;kv_signature=inspect.signature(original_kv)
    @functools.wraps(original_kv)
    def kv(self,*args,**kwargs):
        bound=kv_signature.bind(self,*args,**kwargs)
        bound.arguments['host_token_capacity']=kv_tokens
        original_kv(*bound.args,**bound.kwargs)
        assert self.size==kv_tokens
        emit('kv_budget',tokens=self.size,bytes_per_token=self.size_per_token,
             allocated_bytes=self.size*self.size_per_token)
    MHATokenToKVPoolHost.__init__=kv
    # KDA uses an MLA KV mirror; apply the same explicit token capacity.
    from sglang.srt.mem_cache.pool_host.mla import MLATokenToKVPoolHost
    original_mla=MLATokenToKVPoolHost.__init__;mla_signature=inspect.signature(original_mla)
    @functools.wraps(original_mla)
    def mla(self,*args,**kwargs):
        bound=mla_signature.bind(self,*args,**kwargs)
        bound.arguments['host_token_capacity']=kv_tokens
        original_mla(*bound.args,**bound.kwargs)
        assert self.size==kv_tokens
        emit('kv_budget',tokens=self.size,bytes_per_token=self.size_per_token,
             allocated_bytes=self.size*self.size_per_token,pool_type='mla')
    MLATokenToKVPoolHost.__init__=mla

    def count(cache):return cache.mamba_evictable_size()+cache.mamba_protected_size()
    def room(cache,need):
        used=count(cache)
        excess=max(0,used+need-quota)
        if excess:
            # Nonblocking ack polling, followed by ordinary LRU eviction. No
            # transfer waits/synchronization added to the timing path.
            cache.writing_check()
            result=cache.evict(EvictParams(num_tokens=0,mamba_num=excess))
            emit('l1_quota_eviction',before=used,need=need,after=count(cache),result=str(result))
        return count(cache)+need<=quota
    def device_exists(cache,key):
        result=cache.tree_core.match_prefix(MatchPrefixParams(key=key))
        cache._apply_cache_actions(list(result.cache_actions))
        return (result.device_prefix_len+result.host_hit_length==len(key)
            and cache.tree_core.get_component_device_value(result.best_match_node,ComponentType.MAMBA) is not None)

    original_prepare=MambaComponent.prepare_for_caching_req
    @functools.wraps(original_prepare)
    def prepare(self,req,insert_params,token_ids_len,is_finished):
        length=req.kv.mamba_last_track_seqlen or 0
        if is_finished and self.cache.enable_mamba_extra_buffer:
            checkpoint=self._select_finished_checkpoint(req,token_ids_len)
            if checkpoint is None:return original_prepare(self,req,insert_params,token_ids_len,is_finished)
            length=checkpoint[0]
        if length>0:
            key=RadixKey(req.full_untruncated_fill_ids[:length],req.extra_key,
                is_bigram=self.tree_core.is_eagle,cache_salt=req.cache_salt).page_aligned(self.cache.page_size)
            if not device_exists(self.cache,key) and not room(self.cache,1):
                emit('quota_admission_skip',rid=req.rid,used=count(self.cache))
                return 0
        result=original_prepare(self,req,insert_params,token_ids_len,is_finished)
        return result
    MambaComponent.prepare_for_caching_req=prepare

    original_load=UnifiedRadixCache._load_back_transfers
    @functools.wraps(original_load)
    def load(self,*,node_id,mem_quota,req,result,ancestor_lock_params,host_anchor_params):
        need=int(self.tree_core.get_component_device_value(node_id,ComponentType.MAMBA) is None
            and self.tree_core.component_has_host_value_only(node_id,ComponentType.MAMBA))
        if not room(self,need):
            self.dec_lock_ref(node_id,ancestor_lock_params)
            self.dec_host_lock_ref(node_id,host_anchor_params)
            emit('quota_load_deferred',rid=getattr(req,'rid',None),used=count(self))
            return False
        self._benefit_rid=getattr(req,'rid',None)
        value=original_load(self,node_id=node_id,mem_quota=mem_quota,req=req,result=result,
            ancestor_lock_params=ancestor_lock_params,host_anchor_params=host_anchor_params)
        used=count(self);assert used<=quota,(used,quota,'load')
        emit('load_back',rid=getattr(req,'rid',None),success=value,mamba_requested=bool(need),l1_used=used)
        return value
    UnifiedRadixCache._load_back_transfers=load

    original_insert=UnifiedRadixCache.insert
    @functools.wraps(original_insert)
    def insert(self,params):
        value=original_insert(self,params)
        used=count(self);assert used<=quota,(used,quota,'insert')
        emit('l1_occupancy',used=used,quota=quota)
        return value
    UnifiedRadixCache.insert=insert

    original_match=UnifiedRadixCache.match_prefix
    @functools.wraps(original_match)
    def match(self,params):
        value=original_match(self,params)
        if params.req is not None:
            emit('match',rid=params.req.rid,device=value.device_prefix_len,
                host=value.host_hit_length,mamba_host=value.mamba_host_hit_length,
                l1_used=count(self))
        return value
    UnifiedRadixCache.match_prefix=match

    original_backup=MambaPoolHost.backup_from_device_all_layer
    @functools.wraps(original_backup)
    def backup(self,pool,hi,di,*args,**kwargs):
        value=original_backup(self,pool,hi,di,*args,**kwargs)
        emit('d2h',slots=di.numel(),bytes=di.numel()*self.size_per_token,host_available=self.available_size())
        return value
    MambaPoolHost.backup_from_device_all_layer=backup
    original_h2d=MambaPoolHost.load_to_device_per_layer
    @functools.wraps(original_h2d)
    def h2d(self,pool,hi,di,layer,*args,**kwargs):
        value=original_h2d(self,pool,hi,di,layer,*args,**kwargs)
        if layer==self.num_mamba_layers-1:emit('h2d',slots=di.numel(),bytes=di.numel()*self.size_per_token)
        return value
    MambaPoolHost.load_to_device_per_layer=h2d

    original_forward=ModelRunner.forward
    @functools.wraps(original_forward)
    def forward(self,forward_batch,*args,**kwargs):
        if forward_batch.forward_mode.is_extend():
            emit('prefill',tokens=forward_batch.extend_num_tokens,
                seq_lens=forward_batch.extend_seq_lens_cpu,prefix_lens=forward_batch.extend_prefix_lens_cpu)
        return original_forward(self,forward_batch,*args,**kwargs)
    ModelRunner.forward=forward


    original_load_model=ModelRunner.load_model
    @functools.wraps(original_load_model)
    def load_model(self,*args,**kwargs):
        original_load_model(self,*args,**kwargs)
        # Startup only. Keep the original model config, MRoPE and text forward
        # implementation. No timed request contains image/video inputs.
        if model_name!='gdn':return
        assert not getattr(self.model,'language_model_only',False)
        assert getattr(self.model,'is_mrope_enabled',False)
        vision=self.model.visual
        vision.to('cpu')
        def no_vision_forward(*args,**kwargs):
            raise RuntimeError('This token-only benchmark prohibits vision forward; use --skip-server-warmup')
        vision.forward=no_vision_forward
        torch.cuda.empty_cache()
        emit('unused_vision_cpu',parameter_bytes=sum(p.numel()*p.element_size() for p in vision.parameters()))
    ModelRunner.load_model=load_model

    original_runner_init=ModelRunner.__init__
    @functools.wraps(original_runner_init)
    def runner_init(self,*args,**kwargs):
        original_runner_init(self,*args,**kwargs)
        if model_name!='gdn':
            emit('runtime_model',model_class=type(self.model).__name__,parameter_bytes=sum(p.numel()*p.element_size() for p in self.model.parameters()))
            return
        text_only=getattr(self.model,'language_model_only',False)
        visual_device=next(self.model.visual.parameters()).device.type
        assert not text_only and visual_device=='cpu' and self.model.is_mrope_enabled
        assert all(p.device.type=='cuda' for name,p in self.model.named_parameters() if not name.startswith('visual.'))
        emit('runtime_model',model_class=type(self.model).__name__,language_model_only=text_only,
             visual_parameter_device=visual_device,is_mrope_enabled=self.model.is_mrope_enabled,
             parameter_bytes=sum(p.numel()*p.element_size() for p in self.model.parameters()))
    ModelRunner.__init__=runner_init

    # Precision experiment only: force production L2 eviction before each real
    # continuation. This is not used to time performance or memory allocation.
    prior_match=UnifiedRadixCache.match_prefix
    @functools.wraps(prior_match)
    def chain_match(self,params):
        c=command();rid=getattr(params.req,'rid',None)
        if c.get('experiment')=='chain' and c.get('rid')==rid and c.get('tier')=='l2' and c.get('expected_cached',0)>0 and getattr(self,'_chain_evicted_rid',None)!=rid:
            self.writing_check(write_back=True)
            torch.cuda.synchronize()
            result=self.evict(EvictParams(num_tokens=c['expected_cached'],mamba_num=32))
            self._chain_evicted_rid=rid
            emit('chain_forced_eviction',rid=rid,expected_cached=c['expected_cached'],result=str(result))
        return prior_match(self,params)
    UnifiedRadixCache.match_prefix=chain_match

    from sglang.srt.mem_cache.mamba_checkpoint_pool import MambaCheckpointPool
    prior_encode=MambaCheckpointPool.store_from_active
    @functools.wraps(prior_encode)
    def encode(self,active,src,dst):
        result=prior_encode(self,active,src,dst)
        c=command()
        emit('codec_store',rid=c.get('rid'),slots=src.numel(),kind=c.get('kind'),depth=c.get('depth'),step=c.get('step'))
        return result
    MambaCheckpointPool.store_from_active=encode
    prior_decode=MambaCheckpointPool.load_to_active
    @functools.wraps(prior_decode)
    def decode(self,active,src,dst):
        result=prior_decode(self,active,src,dst)
        c=command()
        emit('codec_load',rid=c.get('rid'),slots=src.numel(),kind=c.get('kind'),depth=c.get('depth'),step=c.get('step'))
        return result
    MambaCheckpointPool.load_to_active=decode

    from sglang.srt.mem_cache.kv.router import STATE_PART
    prior_cow=ModelRunner._maybe_execute_deferred_mamba_cow_and_clear
    @functools.wraps(prior_cow)
    def chain_cow(self,batch):
        result=prior_cow(self,batch)
        c=command();rid=c.get('rid')
        if (c.get('experiment')=='chain' and c.get('capture_state') and batch.forward_mode.is_extend()
            and rid and getattr(self,'_chain_captured_rid',None)!=rid):
            self.token_to_kv_pool.layer_router.wait_for_part(STATE_PART)
            torch.cuda.synchronize()
            pool=self.req_to_token_pool;state=self.token_to_kv_pool_allocator.state
            logical=pool.get_mamba_indices(batch.req_pool_indices)
            physical=self.runner_ids.state_ids(pool.state_sub_pool).ids(logical).reshape(-1)
            assert physical.numel()==1 and physical.item()>0,physical
            tensors=state.pool.mamba_cache
            layers=sorted({0,tensors.temporal.shape[0]//2,tensors.temporal.shape[0]-1})
            idx=torch.tensor(layers,device=tensors.temporal.device)
            temporal=tensors.temporal.index_select(0,idx).index_select(1,physical.long()).detach().cpu()
            conv=[v.index_select(0,idx).index_select(1,physical.long()).detach().cpu() for v in tensors.conv]
            dest=root/'states';dest.mkdir(exist_ok=True)
            file=dest/f'{rid}.pid{os.getpid()}.pt'
            torch.save(dict(rid=rid,model=model_name,layers=layers,temporal=temporal,conv=conv,
                full_temporal_shape=list(tensors.temporal.shape),checkpoint_depth=c['depth'],tp_rank=int(self.gpu_id)),file)
            emit('state_snapshot',rid=rid,path=str(file),layers=layers,shape=list(temporal.shape),tp_rank=int(self.gpu_id))
            self._chain_captured_rid=rid
        return result
    ModelRunner._maybe_execute_deferred_mamba_cow_and_clear=chain_cow

import hashlib,json,re
from pathlib import Path
from transformers import AutoTokenizer
r=Path(__file__).resolve().parent
p=json.loads((r/'protocol.json').read_text())
t=AutoTokenizer.from_pretrained(p['models']['kda']['tokenizer'],local_files_only=True,trust_remote_code=True)
train=[json.loads(l) for l in Path('/mnt/sll/experiments/int8-checkpoint-accuracy-20261103/gsm8k_train.jsonl').read_text().splitlines()]
prefixes=[]
for key in range(72):
    head=t.encode(f'<|im_system|>system<|im_middle|>Document ID: {key:04d}. You are a helpful assistant. Use the reference notes below.\n',add_special_tokens=False)
    body=t.encode(('\n'.join(x['question']+' '+re.sub(r'<<.*?>>','',x['answer']) for x in train[key*20:key*20+30]))*4,add_special_tokens=False)
    tail=t.encode('<|im_end|>',add_special_tokens=False)
    ids=head+body[:1024-len(head)-len(tail)]+tail
    assert len(ids)==1024
    prefixes.append(ids)
assert len({tuple(x[:256]) for x in prefixes})==72
suffix=[]
for i in range(256):
    head=t.encode(f'<|im_user|>user<|im_middle|>Request {i:04d}: State one useful fact from these notes. ',add_special_tokens=False)
    middle=t.encode('Please keep the response concise. '*20,add_special_tokens=False)
    tail=t.encode('<|im_end|><|im_assistant|>assistant<|im_middle|>',add_special_tokens=False)
    ids=head+middle[:64-len(head)-len(tail)]+tail
    assert len(ids)==64;suffix.append(ids)
for name,value in [('prefixes_kda.json',{'1024':prefixes}),('suffixes_kda.json',suffix)]:
    path=r/name;path.write_text(json.dumps(value,separators=(',',':'))+'\n')
    p['hashes'][name]=hashlib.sha256(path.read_bytes()).hexdigest()
# Check IDs against actual model embedding vocabulary, not len(tokenizer).
config=json.loads(Path(p['models']['kda']['model'],'config.json').read_text());vocab=config.get('vocab_size',config.get('text_config',{}).get('vocab_size'))
assert vocab and max(x for row in prefixes+suffix for x in row)<vocab
p['memory_model_native_fixture_note']='GDN and KDA use separate tokenizer-native 72-prefix/suffix fixtures. Geometry, prefix length, output length and cache capacities match; raw vocabulary IDs are never shared between models.'
(r/'protocol.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
print('KDA memory fixtures validated against vocab',vocab)

"""Full evaluation starts only after both pilot/allocation gates succeed."""
import hashlib,json,math,os,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def job(fmt,name,pilot=False):
    if (ROOT/'runs'/name/'DONE').exists():return
    cmd=[sys.executable,str(ROOT/'run.py'),fmt,name]+(['--pilot'] if pilot else [])
    print('START',name,flush=True)
    with (ROOT/(name+'.log')).open('w') as out:subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
    print('DONE',name,flush=True)
def gate():
    data={}
    for fmt in ['bf16','int8']:
        folder=ROOT/'runs'/f'pilot_{fmt}'
        assert (folder/'DONE').exists(),folder
        a=json.loads((folder/'allocation.json').read_text());v=json.loads((folder/'validation.json').read_text())
        assert v['l1_peak']==v['quota']==8
        data[fmt]=dict(allocation=a,validation=v,cases=json.loads((folder/'cases.json').read_text()))
    control=json.loads((ROOT/'runs/pilot_bf16/text_only_output_control.json').read_text())
    assert control['equal_output_sequences']==control['cases']==32
    a=data['bf16']['allocation'];b=data['int8']['allocation']
    assert a['mamba'][0]['budget_bytes']==b['mamba'][0]['budget_bytes']==P['mamba_l2_budget_bytes']
    assert a['mamba'][0]['slots']==72 and b['mamba'][0]['slots']==136
    assert a['kv'][0]['allocated_bytes']==b['kv'][0]['allocated_bytes']
    assert b['mamba'][0]['slots']>a['mamba'][0]['slots']>P['l1_cache_slots']
    counts={}
    for c in [1,8]:
        rates=[case['requests_per_s'] for arm in data.values() for case in arm['cases'] if case['name']==f'pilot_hot_c{c}']
        # Conservative common request count from the fastest L1-hot pilot.
        counts[str(c)]=max(192 if c==1 else 512,math.ceil(max(rates)*90/8)*8)
        assert counts[str(c)]<=8192
    save(ROOT/'request_counts.json',counts)
    save(ROOT/'ALIGNMENT_GATE_PASSED.json',dict(time=time.time(),counts=counts,pilots=data,
        runner_sha256=hashlib.sha256((ROOT/'run.py').read_bytes()).hexdigest(),hook_sha256=hashlib.sha256((ROOT/'audit/sitecustomize.py').read_bytes()).hexdigest()))
    print('ALIGNMENT_GATE_PASSED',counts,flush=True)
if __name__=='__main__':
    save(ROOT/'PIPELINE_PID.json',dict(pid=os.getpid(),started=time.time()))
    try:
        job('bf16','pilot_bf16',True);job('int8','pilot_int8',True);gate()
        for rep in range(P['repeats']):
            for fmt in (['bf16','int8'] if rep%2==0 else ['int8','bf16']):
                job(fmt,f'r{rep}_{fmt}')
                subprocess.run([sys.executable,str(ROOT/'analyze.py')],check=True)
        (ROOT/'ALL_RUNS_DONE').touch()
        subprocess.run([sys.executable,str(ROOT/'analyze.py'),'--final'],check=True)
    except BaseException:
        (ROOT/'PIPELINE_FAILED').write_text(traceback.format_exc());raise

import hashlib,json,random
from pathlib import Path
from transformers import AutoTokenizer
root=Path(__file__).resolve().parent
p=json.loads((root/'protocol.json').read_text())
assert not (root/'prefixes.json').exists()
tok=AutoTokenizer.from_pretrained(p['model'],local_files_only=True)
rows=[json.loads(x) for x in Path('/mnt/sll/experiments/int8-checkpoint-accuracy-20261103/gsm8k_train.jsonl').read_text().splitlines()]
work={}
for length in [1024,2048,4096]:
    cases=[]
    for key in range(192):
        head=tok.encode(f'<|im_start|>system\nDocument ID: {key:04d}. You are a helpful assistant. Use the following reference notes to answer short questions.\n',add_special_tokens=False)
        text='\n'.join(r['question']+' '+r['answer'] for r in rows[key*20:key*20+30])
        body=tok.encode(text*8,add_special_tokens=False)
        tail=tok.encode('<|im_end|>\n',add_special_tokens=False)
        ids=head+body[:length-len(head)-len(tail)]+tail
        assert len(ids)==length
        cases.append(ids)
    assert len({tuple(x[:256]) for x in cases})==len(cases)
    work[str(length)]=cases
(root/'prefixes.json').write_text(json.dumps(work,separators=(',',':'))+'\n')
# Preserve the original query suffix tokens, including the fixed output prompt.
old=Path(p['parent_performance_experiment'])
(root/'suffixes.json').write_bytes((old/'suffixes.json').read_bytes())
scenarios=[dict(length=1024,working_set=n,access=a,concurrency=8,name=f'p1024_n{n}_{a}_c8')
    for n in [48,96,160] for a in ['cyclic','zipf']]
scenarios += [dict(length=l,working_set=20,access=a,concurrency=8,name=f'p{l}_n20_{a}_c8')
    for l in [2048,4096] for a in ['cyclic','zipf']]
random.Random(20261104).shuffle(scenarios)
sequences={}
for s in scenarios:
    rng=random.Random(20261104+s['length']+s['working_set'])
    if s['access']=='cyclic':keys=[i%s['working_set'] for i in range(8192)]
    else:keys=rng.choices(range(s['working_set']),weights=[1/(i+1)**1.1 for i in range(s['working_set'])],k=8192)
    sequences[s['name']]=keys
(root/'sequences.json').write_text(json.dumps(sequences,separators=(',',':'))+'\n')
p['scenarios']=scenarios
p['hashes']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['prefixes.json','suffixes.json','sequences.json']}
p['warmup']='Seed each working-set prefix once; run max(32, 2*N) untimed requests using the scenario access stream, then start its fixed timed stream from index zero.'
(root/'protocol.json').write_text(json.dumps(p,indent=2)+'\n')
print('Frozen',len(scenarios),'C8 scenarios; Mamba L2 byte budget',p['mamba_l2_budget_bytes'])

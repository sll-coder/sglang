"""Paired service-restart summaries; preserve negative and noisy outcomes."""
import csv,json,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
def mean(xs):return statistics.mean(xs)
def analyze(final=False):
    runs={};alloc={};validations={}
    for rep in range(P['repeats']):
        for fmt in ['bf16','int8']:
            folder=ROOT/'runs'/f'r{rep}_{fmt}'
            if not (folder/'DONE').exists():continue
            runs[(rep,fmt)]={c['name']:c for c in json.loads((folder/'cases.json').read_text())}
            alloc[folder.name]=json.loads((folder/'allocation.json').read_text())
            validations[folder.name]=json.loads((folder/'validation.json').read_text())
    if final:assert len(runs)==P['repeats']*2
    comparisons=[]
    for cfg in P['scenarios']:
        pairs=[]
        for rep in range(P['repeats']):
            if (rep,'bf16') not in runs or (rep,'int8') not in runs:continue
            a=runs[(rep,'bf16')][cfg['name']];b=runs[(rep,'int8')][cfg['name']]
            assert a['n']==b['n']
            pairs.append(dict(rep=rep,bf16=a,int8=b,
                ttft_p50_change_pct=(b['ttft_p50_s']/a['ttft_p50_s']-1)*100,
                ttft_p95_change_pct=(b['ttft_p95_s']/a['ttft_p95_s']-1)*100,
                request_throughput_change_pct=(b['requests_per_s']/a['requests_per_s']-1)*100,
                recompute_change_pct=(b['mean_prefix_tokens_recomputed']/a['mean_prefix_tokens_recomputed']-1)*100 if a['mean_prefix_tokens_recomputed'] else None))
        if not pairs:continue
        item=dict(**cfg,paired_repeats=len(pairs),pairs=pairs,
            ttft_p50_change_pct_mean=mean([x['ttft_p50_change_pct'] for x in pairs]),
            ttft_p50_change_pct_range=[min(x['ttft_p50_change_pct'] for x in pairs),max(x['ttft_p50_change_pct'] for x in pairs)],
            ttft_p95_change_pct_mean=mean([x['ttft_p95_change_pct'] for x in pairs]),
            request_throughput_change_pct_mean=mean([x['request_throughput_change_pct'] for x in pairs]),
            request_throughput_change_pct_range=[min(x['request_throughput_change_pct'] for x in pairs),max(x['request_throughput_change_pct'] for x in pairs)])
        for fmt in ['bf16','int8']:
            arm=[x[fmt] for x in pairs]
            item[fmt]=dict(ttft_p50_ms=mean([x['ttft_p50_s']*1000 for x in arm]),
                ttft_p95_ms=mean([x['ttft_p95_s']*1000 for x in arm]),requests_per_s=mean([x['requests_per_s'] for x in arm]),
                full_prefix_reuse_rate=mean([x['full_prefix_reuse_rate'] for x in arm]),
                l1_hit_rate=mean([x['audit']['l1_hit_rate'] for x in arm]),
                l2_restore_rate=mean([x['audit']['l2_restore_rate'] for x in arm]),
                state_miss_rate=mean([x['audit']['state_miss_rate'] for x in arm]),
                mean_prefix_tokens_recomputed=mean([x['mean_prefix_tokens_recomputed'] for x in arm]),
                window_min_seconds=min(x['elapsed_s'] for x in arm),window_max_seconds=max(x['elapsed_s'] for x in arm),
                quota_admission_skips=sum(x['audit']['quota_admission_skips'] for x in arm),
                quota_load_deferrals=sum(x['audit']['quota_load_deferrals'] for x in arm))
        comparisons.append(item)
    result=dict(final=final,source_commit=P['source_commit'],protocol=P,completed_runs=list(alloc),
        allocations=alloc,validations=validations,comparisons=comparisons)
    (ROOT/('RESULTS.json' if final else 'PARTIAL_RESULTS.json')).write_text(json.dumps(result,indent=2)+'\n')
    if not final:return
    header=['scenario','format','paired_repeats','ttft_p50_ms','ttft_p95_ms','requests_per_s','l1_hit_rate','l2_restore_rate','state_miss_rate','mean_prefix_tokens_recomputed','window_min_seconds','quota_admission_skips','quota_load_deferrals']
    with (ROOT/'SUMMARY.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=header,extrasaction='ignore');w.writeheader()
        for x in comparisons:
            for fmt in ['bf16','int8']:w.writerow(dict(scenario=x['name'],format=fmt,paired_repeats=x['paired_repeats'],**x[fmt]))
    lines=['# INT8 Mamba state 接入 HiCache L2：等容量对比','',
        f"模型：`{P['model']}`，BF16 权重；独立 002 `{P['source_commit']}`，原 eager codec，无 001/003。两组都开启 L2。",'',
        '## 对齐方式','',
        f"每个 TP rank 的 L1 树节点缓存状态上限为 {P['l1_cache_slots']} 槽，活动状态物理池为 {P['active_pool_slots']} 槽。使用同一实验侧 admission/load 配额，通过生产 LRU 驱逐实现；锁定状态无法回收时跳过缓存或拒绝本次回迁，并记录次数。配额只限制树节点中的缓存状态，不把请求运行状态算成额外缓存。",'',
        f"Mamba L2 预算为每 rank {P['mamba_l2_budget_bytes']/1024**2:.0f} MiB，包括 temporal、conv、scale。按完整状态向下取整；实际 payload 与不能容纳完整槽位的预算余量分别记录。KV L1 为 {P['kv_l1_tokens']} tokens，KV L2 为 {P['kv_l2_tokens']} tokens。",'',
        '```json',json.dumps({name:dict(l1_quota=x['l1_cache_slot_quota'],mamba={k:x['mamba'][0][k] for k in ['budget_bytes','allocated_bytes','bytes_per_slot','slots','unused_budget_bytes']},kv={k:x['kv'][0][k] for k in ['tokens','allocated_bytes']}) for name,x in alloc.items()},indent=2),'```','',
        '## 工作负载与计时','',
        '服务 --hicache-ratio=2、--max-running-requests=8。KV L2 实际为 KV L1 的 2 倍；Mamba L2 独立预算精确等于 72 个完整 BF16 状态的大小，同预算向下取整容纳 136 个 INT8 状态。', '',
        '1K/N96 的 KV 需求为 98304 tokens，小于 131072-token KV L2，同时状态工作集超过 BF16 的 72 槽、落在 INT8 的 136 槽以内。1K/N160 同时超过 KV 与两种 Mamba 容量，只作为整体缓存溢出压力，不能把全部差异单独归因于 Mamba。2K/4K N20 两组状态都放得下，用于检查容量充裕时的开销。', '',
        '正式并发为 8。容量主实验使用 1K 前缀和 48/96/160 个前缀的工作集；另保留 2K/4K 前缀、工作集 20 的等命中对照。每种配置各测固定轮转与固定种子的 Zipf 热点访问，共 10 个场景、每格式 3 次独立服务重启。64-token 不同查询后缀，固定生成 32 tokens（ignore_eos）；前缀在第一个 256-token page 内不同。', '',
        '每个场景独立清空缓存、预热，再测量。两组及所有重复使用相同请求数量、前缀、每个 worker 的访问序列；并发下服务实际调度交错可能不同。请求数由独立 pilot 统一冻结，逐场景列出实际计时长度。启动、预热、原始数据序列化和额外校验不计入计时。', '',
        '两组保持原模型配置、MRoPE 和文本计算路径，仅在实验启动时将未使用的视觉模块放到 CPU，为对齐后的 KV 池留出空间；非视觉权重全部保留在 GPU，计时中不进行文本权重 offload。为避免长前缀产生额外的中间 chunk checkpoint，两组均关闭 chunked prefill，prefill batch token 上限为 8192。prefill CUDA Graph 关闭，decode CUDA Graph 最大 batch 为 8。没有强制驱逐指定目标、篡改状态或注入命中；运行时没有增加逐项传输同步。','',
        'TTFT 为客户端流式请求至首次非空输出事件。吞吐按整段请求完成墙钟时间计算。重算量为前缀长度减实际复用 token 数；另记录模型实际执行的 prefill token 数。Mamba L2 恢复依据双 rank 生产回迁记录，不能只用 attention KV 的 host/device token 报告代替。','',
        '## 结果','',
        '下表为三轮各自统计值的均值；完整原始每轮数据和比值范围见 RESULTS.json。吞吐变化为三轮配对比值的均值。','',
        '| 场景 | BF16 / INT8 L2 恢复率 | BF16 / INT8 状态未命中率 | BF16 / INT8 每请求前缀重算 tokens | BF16 / INT8 TTFT P50（ms） | BF16 / INT8 请求/s | 吞吐变化 |',
        '|---|---|---|---|---|---|---|']
    for x in sorted(comparisons,key=lambda x:(x['length'],x['working_set'],x['access'],x['concurrency'])):
        a=x['bf16'];b=x['int8']
        lines.append(f"| {x['name']} | {a['l2_restore_rate']*100:.1f}% / {b['l2_restore_rate']*100:.1f}% | {a['state_miss_rate']*100:.1f}% / {b['state_miss_rate']*100:.1f}% | {a['mean_prefix_tokens_recomputed']:.1f} / {b['mean_prefix_tokens_recomputed']:.1f} | {a['ttft_p50_ms']:.1f} / {b['ttft_p50_ms']:.1f} | {a['requests_per_s']:.2f} / {b['requests_per_s']:.2f} | {x['request_throughput_change_pct_mean']:+.1f}% |")
    lines+=['','## 验证与限制','',
        'L1 上限在每次插入/回迁后断言，启动时检查双 rank 实际 L2 槽位和字节数。所有计时请求必须生成完整 32 tokens、无错误和 retraction。计数、槽位、自然命中路径及 admission skip/load defer 保留原始日志。','',
        '该配额与独立预算配置属于实验驱动，不包含于生产 002，也不代表相同原生启动参数即可得到同样分配。BF16 与 INT8 仍使用各自生产恢复和编解码路径；不同的请求状态池关系、pin 行为和编码开销是实际方案的一部分。若配额跳过或回迁拒绝存在，应结合次数解释命中差异。','',
        'L2 预算也容纳 L1 数据的 host backup，并非 L1 槽位数加 L2 槽位数的完全独立容量。固定轮转可能放大容量边界的收益，因此同时保留热点访问和两边均溢出的结果。端到端差异不等同于传输 kernel 加速；没有对 decode 质量作新评估，精度结论参见之前独立 GSM8K 实验。','',
        '这里报告单机双 RTX 5090、固定输出和服务配置的结果，不外推任意并发、长输出、其他模型和硬件。原始 GPU 显存、功耗、时钟、温度采样保留在各 run 的 gpu.jsonl 中。']
    (ROOT/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n')
    import subprocess,sys
    subprocess.run([sys.executable,str(ROOT/'plot.py')],check=True)
    (ROOT/'ARTIFACTS_READY').touch()
    print('ARTIFACTS_READY',len(comparisons),'paired scenarios')
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');a=p.parse_args();analyze(a.final)

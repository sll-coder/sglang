# 002 L2 experiment: ratio 2, C8, budget for 72 BF16 states

This replaces the unfinished 512 MiB experiment in ../int8-l2-benefit-20261104, which was stopped at the user's configuration change. Its partial measurements and diagnostics remain separate; they will not be pooled with this experiment.

## Requested settings and actual allocations

- Both formats launch with **--hicache-ratio 2** and **--max-running-requests 8**. Formal client concurrency is also 8. The serial pilot is only an output/sanity control and is excluded from formal performance results.
- Every TP rank gets a Mamba L2 upper budget of **2,824,077,312 bytes = 2693.25 MiB = 2.630126953125 GiB**, exactly **72 × 39,223,296 bytes**, the measured complete BF16 state size including temporal and conv.
- The INT8 complete state is 20,643,840 bytes, including qdata, conv and native scales. The same budget fits **136 INT8 states**, consuming 2,807,562,240 bytes, with 16,515,072 bytes unusable as another whole slot.
- Node-wide Mamba budget across TP2 is 5.26025390625 GiB. Capacity in distinct prefixes remains 72 BF16 / 136 INT8 because both ranks store their own shard for each prefix.
- Logical L1 tree-state cache quota remains **8 slots** in both groups. Both have the same physical 32-slot active pool; INT8 has a physical 16-slot checkpoint pool. Quota uses the same production LRU admission/load path in both formats. Physical spare slots are not admitted as extra cached states.
- Attention KV L1 remains 65536 tokens. KV L2 is **131072 tokens = exactly 2× L1**, or 2 GiB per rank. The host constructor fixes the exact capacity to avoid the default extra-page rounding. Thus ratio 2 changes the actual KV capacity, rather than only the printed command. Mamba L2 uses the independent user-requested byte budget, overriding its ratio-based default.

## Why the workload changes

With ratio 2 and 2K/4K prefixes, KV L2 holds only about 64/32 whole prefixes, below the new 72-state BF16 Mamba capacity. It would therefore limit reuse before Mamba capacity could be isolated.

The main capacity experiment uses **1K prefixes** with working sets **48 / 96 / 160**. At N96, the KV working set is 98304 tokens, below the 131072-token KV L2; 96 states exceed BF16's 72 slots but fit INT8's 136. This is the capacity comparison. N48 fits both groups. N160 exceeds both state pools and the KV pool; report it as total-system overflow, not pure Mamba-capacity evidence.

Retain **2K and 4K prefixes, N20**, fitting both Mamba pools, to test the old workload at the larger budget and expose codec/transfer overhead when extra state capacity is unnecessary.

All configurations use cyclic and fixed-seed Zipf access, concurrency 8: **10 formal scenarios × 2 formats × 3 independent paired restarts**. No L2-off group or fused codec. Source is independent 002 commit 15a00b66a6b388c5c795d533e4ef21a6ee92ff5e, unchanged; 001/003 are excluded.

## Correctness and timing controls

Use BF16-weight Qwen3.8-27B, BF16 active state, FP8 E4M3 KV, fixed 64-token query suffix and exactly 32 generated tokens (temperature 0, ignore_eos). Prefixes differ within their first page. Chunked prefill and prefill CUDA Graph are disabled, max prefill batch tokens is 8192, decode CUDA Graph max batch is 8.

Retain the original model configuration, MRoPE and text forward path. The experiment-only post-load hook places unused visual weights on CPU; all non-visual weights stay on GPU. Skip default server image warmup and run token-only warmups. A guard forbids any accidental vision forward. BF16 pilot must reproduce all 32 fixed serial output sequences from the original full-model/all-GPU diagnostic; both groups verify actual placement on both ranks.

Both groups use the same logical L1 quota and exact host budgets. No named target is forcibly evicted to manufacture a hit; no state values, matching rules, codec formulas or restore values are replaced. No extra GPU transfer synchronization is added to timed traffic.

Every scenario seeds each prefix, warms max(32, 2*N) requests using the scenario's access stream, then starts the frozen timed stream from index zero. Both formats and all repeats have the same request counts and per-worker key subsequences; actual concurrent interleaving can differ. Counts are frozen from independent L1-hot pilots using the fastest observed rate × 90 seconds, rounded to multiples of 8. Actual durations are reported. Warmup, serialization and validation are outside timing.

Record client TTFT, completed request throughput, Mamba L1 hits/L2 restores/misses, prefix tokens recomputed, actual model prefill tokens and GPU telemetry. Computed input totals must match actual prefill totals on each TP rank; each successful Mamba restore must appear on both ranks. Every request must complete 32 tokens with no error/retraction. Each main service passes a separate untimed natural L2-path gate before its formal scenarios.

## Execution and output

pipeline.py runs both pilots, verifies 72/136 state allocation and matching KV budgets, freezes request counts, then runs three paired restarts in alternating format order. A failed check stops later work and writes PIPELINE_FAILED. progress.py shows compact status. The pipeline PID is recorded in PIPELINE_PID.json.

After completion, analyze.py produces RESULTS.json, SUMMARY.csv, REPORT_ZH.md and benefit_1k.png/pdf. ARTIFACTS_READY exists only after analysis and figures succeed. Keep every launch/config hash, allocation record, request, path/quota audit and GPU sample. No GitHub write or PR-description change is performed.

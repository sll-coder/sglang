# INT8 Mamba state 接入 HiCache L2：等容量对比

模型：`/mnt/sll/models/Qwen3.8-27B`，BF16 权重；独立 002 `15a00b66a6b388c5c795d533e4ef21a6ee92ff5e`，原 eager codec，无 001/003。两组都开启 L2。

## 对齐方式

每个 TP rank 的 L1 树节点缓存状态上限为 8 槽，活动状态物理池为 32 槽。使用同一实验侧 admission/load 配额，通过生产 LRU 驱逐实现；锁定状态无法回收时跳过缓存或拒绝本次回迁，并记录次数。配额只限制树节点中的缓存状态，不把请求运行状态算成额外缓存。

Mamba L2 预算为每 rank 2693 MiB，包括 temporal、conv、scale。按完整状态向下取整；实际 payload 与不能容纳完整槽位的预算余量分别记录。KV L1 为 65536 tokens，KV L2 为 131072 tokens。

```json
{
  "r0_bf16": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2824077312,
      "bytes_per_slot": 39223296,
      "slots": 72,
      "unused_budget_bytes": 0
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  },
  "r0_int8": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2807562240,
      "bytes_per_slot": 20643840,
      "slots": 136,
      "unused_budget_bytes": 16515072
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  },
  "r1_bf16": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2824077312,
      "bytes_per_slot": 39223296,
      "slots": 72,
      "unused_budget_bytes": 0
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  },
  "r1_int8": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2807562240,
      "bytes_per_slot": 20643840,
      "slots": 136,
      "unused_budget_bytes": 16515072
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  },
  "r2_bf16": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2824077312,
      "bytes_per_slot": 39223296,
      "slots": 72,
      "unused_budget_bytes": 0
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  },
  "r2_int8": {
    "l1_quota": 8,
    "mamba": {
      "budget_bytes": 2824077312,
      "allocated_bytes": 2807562240,
      "bytes_per_slot": 20643840,
      "slots": 136,
      "unused_budget_bytes": 16515072
    },
    "kv": {
      "tokens": 131072,
      "allocated_bytes": 2147483648
    }
  }
}
```

## 工作负载与计时

服务 --hicache-ratio=2、--max-running-requests=8。KV L2 实际为 KV L1 的 2 倍；Mamba L2 独立预算精确等于 72 个完整 BF16 状态的大小，同预算向下取整容纳 136 个 INT8 状态。

1K/N96 的 KV 需求为 98304 tokens，小于 131072-token KV L2，同时状态工作集超过 BF16 的 72 槽、落在 INT8 的 136 槽以内。1K/N160 同时超过 KV 与两种 Mamba 容量，只作为整体缓存溢出压力，不能把全部差异单独归因于 Mamba。2K/4K N20 两组状态都放得下，用于检查容量充裕时的开销。

正式并发为 8。容量主实验使用 1K 前缀和 48/96/160 个前缀的工作集；另保留 2K/4K 前缀、工作集 20 的等命中对照。每种配置各测固定轮转与固定种子的 Zipf 热点访问，共 10 个场景、每格式 3 次独立服务重启。64-token 不同查询后缀，固定生成 32 tokens（ignore_eos）；前缀在第一个 256-token page 内不同。

每个场景独立清空缓存、预热，再测量。两组及所有重复使用相同请求数量、前缀、每个 worker 的访问序列；并发下服务实际调度交错可能不同。请求数由独立 pilot 统一冻结，逐场景列出实际计时长度。启动、预热、原始数据序列化和额外校验不计入计时。

两组保持原模型配置、MRoPE 和文本计算路径，仅在实验启动时将未使用的视觉模块放到 CPU，为对齐后的 KV 池留出空间；非视觉权重全部保留在 GPU，计时中不进行文本权重 offload。为避免长前缀产生额外的中间 chunk checkpoint，两组均关闭 chunked prefill，prefill batch token 上限为 8192。prefill CUDA Graph 关闭，decode CUDA Graph 最大 batch 为 8。没有强制驱逐指定目标、篡改状态或注入命中；运行时没有增加逐项传输同步。

TTFT 为客户端流式请求至首次非空输出事件。吞吐按整段请求完成墙钟时间计算。重算量为前缀长度减实际复用 token 数；另记录模型实际执行的 prefill token 数。Mamba L2 恢复依据双 rank 生产回迁记录，不能只用 attention KV 的 host/device token 报告代替。

## 结果

下表为三轮各自统计值的均值；完整原始每轮数据和比值范围见 RESULTS.json。吞吐变化为三轮配对比值的均值。

| 场景 | BF16 / INT8 L2 恢复率 | BF16 / INT8 状态未命中率 | BF16 / INT8 每请求前缀重算 tokens | BF16 / INT8 TTFT P50（ms） | BF16 / INT8 请求/s | 吞吐变化 |
|---|---|---|---|---|---|---|
| p1024_n48_cyclic_c8 | 100.0% / 100.0% | 0.0% / 0.0% | 0.0 / 0.0 | 227.7 / 194.6 | 9.41 / 9.18 | -2.4% |
| p1024_n48_zipf_c8 | 51.0% / 51.4% | 0.0% / 0.0% | 0.0 / 0.0 | 239.4 / 210.8 | 9.31 / 9.59 | +3.0% |
| p1024_n96_cyclic_c8 | 0.0% / 100.0% | 100.0% / 0.0% | 1024.0 / 0.0 | 1295.6 / 223.7 | 4.01 / 9.38 | +133.9% |
| p1024_n96_zipf_c8 | 48.7% / 55.9% | 6.7% / 0.0% | 68.1 / 0.0 | 255.3 / 211.7 | 8.62 / 9.61 | +11.5% |
| p1024_n160_cyclic_c8 | 0.0% / 0.0% | 100.0% / 100.0% | 1024.0 / 1024.0 | 1294.9 / 1301.4 | 4.02 / 3.98 | -1.2% |
| p1024_n160_zipf_c8 | 48.0% / 59.6% | 15.5% / 3.8% | 158.9 / 38.8 | 361.9 / 219.0 | 7.74 / 9.06 | +17.0% |
| p2048_n20_cyclic_c8 | 100.0% / 100.0% | 0.0% / 0.0% | 0.0 / 0.0 | 231.8 / 230.7 | 9.34 / 9.29 | -0.5% |
| p2048_n20_zipf_c8 | 29.7% / 29.4% | 0.0% / 0.0% | 0.0 / 0.0 | 222.0 / 207.2 | 9.37 / 9.37 | +0.1% |
| p4096_n20_cyclic_c8 | 100.0% / 100.0% | 0.0% / 0.0% | 0.0 / 0.0 | 241.2 / 244.8 | 9.16 / 9.05 | -1.2% |
| p4096_n20_zipf_c8 | 30.7% / 30.5% | 0.0% / 0.0% | 0.0 / 0.0 | 229.0 / 213.8 | 9.35 / 9.47 | +1.3% |

## 验证与限制

L1 上限在每次插入/回迁后断言，启动时检查双 rank 实际 L2 槽位和字节数。所有计时请求必须生成完整 32 tokens、无错误和 retraction。计数、槽位、自然命中路径及 admission skip/load defer 保留原始日志。

该配额与独立预算配置属于实验驱动，不包含于生产 002，也不代表相同原生启动参数即可得到同样分配。BF16 与 INT8 仍使用各自生产恢复和编解码路径；不同的请求状态池关系、pin 行为和编码开销是实际方案的一部分。若配额跳过或回迁拒绝存在，应结合次数解释命中差异。

L2 预算也容纳 L1 数据的 host backup，并非 L1 槽位数加 L2 槽位数的完全独立容量。固定轮转可能放大容量边界的收益，因此同时保留热点访问和两边均溢出的结果。端到端差异不等同于传输 kernel 加速；没有对 decode 质量作新评估，精度结论参见之前独立 GSM8K 实验。

这里报告单机双 RTX 5090、固定输出和服务配置的结果，不外推任意并发、长输出、其他模型和硬件。原始 GPU 显存、功耗、时钟、温度采样保留在各 run 的 gpu.jsonl 中。

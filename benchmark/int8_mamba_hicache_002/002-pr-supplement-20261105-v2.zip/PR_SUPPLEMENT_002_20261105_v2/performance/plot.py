"""Primary equal-budget capacity figure, generated only from final results."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'RESULTS.json').read_text());items=r['comparisons']
metrics=[('full_prefix_reuse_rate','Reusable prefix hit rate (%)',100),
         ('mean_prefix_tokens_recomputed','Prefix tokens recomputed / request',1),
         ('ttft_p50_ms','TTFT P50 (ms)',1),('requests_per_s','Request throughput (req/s)',1)]
fig,axes=plt.subplots(1,4,figsize=(17,4.5),layout='constrained')
for ax,(metric,label,scale) in zip(axes,metrics):
    for fmt,color in [('bf16','#386cb0'),('int8','#e67e22')]:
        for access,style,marker in [('cyclic','-','o'),('zipf','--','s')]:
            xs=sorted([x for x in items if x['length']==1024 and x['concurrency']==8 and x['access']==access],key=lambda x:x['working_set'])
            ax.plot([x['working_set'] for x in xs],[x[fmt][metric]*scale for x in xs],color=color,linestyle=style,marker=marker,label=f'{fmt.upper()} / {access}',linewidth=1.8)
    ax.set_title(label,fontsize=11);ax.set_xlabel('Working-set prefixes');ax.set_xticks([48,96,160]);ax.grid(alpha=.22)
    if metric=='full_prefix_reuse_rate':ax.set_ylim(-3,103)
    else:ax.set_ylim(bottom=0)
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=4,frameon=False)
fig.suptitle('1K prefixes, C=8: same 8-state L1 quota and Mamba L2 byte budget\nBF16: 72 states / INT8: 136 states; KV L2: 128 prefix equivalents; mean of 3 restarts',fontsize=13)
fig.savefig(ROOT/'benefit_1k.png',dpi=180);fig.savefig(ROOT/'benefit_1k.pdf');plt.close(fig)
print('Primary capacity figure generated')

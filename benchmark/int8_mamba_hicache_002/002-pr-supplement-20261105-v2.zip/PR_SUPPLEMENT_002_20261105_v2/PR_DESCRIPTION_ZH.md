# [Feat] mem_cache: 支持 INT8 Mamba checkpoint 的 HiCache L1/L2

## Motivation（动机）

已有 INT8 Mamba checkpoint 将缓存状态与 BF16 运行状态分离，但 HiCache 仍从运行状态池读取数据。直接同时启用两者会把 checkpoint ID 当作运行槽位 ID，可能读错状态或越界。

本 PR 让 HiCache 在 GPU L1 和主机内存 L2 之间直接搬运压缩后的 checkpoint。相同主机内存可以缓存更多前缀状态，减少驱逐后的重算。

## Modifications（具体改动）

- 将压缩 checkpoint 池及其分配器接入 HiCache，按 checkpoint 槽位管理驱逐。L2 直接存储 INT8 数据、原精度 scale 和 conv state，无需 BF16 checkpoint 副本，也不在搬运中重新量化。
- 回迁先将数据写回节点的 checkpoint 槽位。等待相关层的主机到 GPU 传输完成后，再用现有 codec 恢复到请求独立的 BF16 运行槽位。
- checkpoint 槽位耗尽时跳过本次缓存；申请或编码失败时归还预留资源，保留请求原有的 tracking slot。
- 首批支持 CUDA、单机 TP、BF16 运行状态，以及 `kernel` IO、`page_first`、`write_through`、`cache` host mode 和 `extra_buffer_lazy` 的组合；启动和运行时均限制未支持的配置，包括 L3。

本 PR 独立于 [#48049（001：通用 HiCache 回滚）](https://github.com/sgl-project/sglang/pull/48049) 和 [#48035（003：codec 融合）](https://github.com/sgl-project/sglang/pull/48035)，沿用 main 的 eager codec 和量化格式。

## Performance Tests（容量与性能）

**相同容量。** 两种格式均实际填满并从 L2 回迁了 72 个不同前缀。下表为每个 TP rank 的 **Mamba L2 主机内存**，含 temporal state、conv state 和 scale。

| 模型 | BF16 checkpoint | INT8 checkpoint | 节省 |
|---|---:|---:|---:|
| GDN：Qwen3.8-27B，BF16 权重（3 轮） | 2.630 GiB | 1.384 GiB | **47.37%** |
| KDA：Kimi-Linear-48B-A3B，AWQ 4bit（1 轮） | 0.753 GiB | 0.406 GiB | **45.99%** |

**相同预算。** 使用 BF16 权重 Qwen3.8-27B，在 2× RTX 5090、TP2、并发 8 下，两组 L1 均为 8 槽，attention KV 容量相同；每 rank 的 2.63 GiB Mamba L2 预算可容纳 **72 个 BF16 或 136 个 INT8 状态（1.89×）**。10 个场景各测三轮，共 52,320 个计时请求。

| 96 个 1K 前缀的访问模式 | Mamba 状态未命中率 | 每请求前缀重算 | TTFT P50 | 请求吞吐 |
|---|---:|---:|---:|---:|
| 固定轮转 | 100% → 0% | 1,024 → 0 tokens | 1,296 → 224 ms | 4.01 → 9.38 req/s（**2.34×**） |
| Zipf 热点 | 6.7% → 0% | 68.1 → 0 tokens | 255 → 212 ms | 8.62 → 9.61 req/s（**+11.5%**） |

收益取决于工作集能否放进缓存：两组都能容纳时，吞吐变化为 −2.4% 至 +3.0%；160 前缀轮转、两组都溢出时为 −1.2%。以上是合成前缀复用负载下减少重算的收益。

## Accuracy Tests（正确性与精度）

**回归和真实服务。** checkpoint 耗尽及资源回收的 5 项回归在未修复 main 上为 3 失败、2 通过，修复后全部通过。相关 CPU / GPU / Rust 分别通过 **431 / 82 / 48** 项；适用的 pre-commit 检查通过。GDN 和 KDA 的 TP2 服务验证完成 **512/512 请求**，并发峰值 8；两张卡均实际执行 L2 备份、驱逐和回迁，校验轮的 INT8 数据、scale 和 conv state 往返逐元素一致。

**单次恢复。** 每个模型配置、每个对照组均跑完 **1,319 道 GSM8K 题**。表中 BF16 / INT8 指 checkpoint 格式。

| 模型 / 权重 | BF16-L1 | INT8-L1 | BF16-L2 | INT8-L2 |
|---|---:|---:|---:|---:|
| GDN / BF16 | 1281 | 1282 | 1281 | 1282 |
| GDN / NVFP4 | 1277 | 1276 | 1277 | 1276 |
| KDA / AWQ 4bit | 1124 | 1133 | 1135 | 1123 |

两种 GDN 权重配置下，INT8 相对 BF16 的答对题数分别为 **+1、−1**，参考答案的平均绝对 logprob 差分别为 **0.01237、0.06771**。固定 checkpoint 格式后，两种 GDN 配置的 L1/L2 均为 **1,319/1,319 生成序列一致、逐 token logprob 差为 0**。KDA 的 INT8/BF16 平均绝对 logprob 差为 **0.02940**；现有数据无法将量化和 L2 的影响与同路径复算波动清晰分离。

**连续恢复。** 固定最终 8K 前缀，在 32 道 GSM8K 题上测试 1、4、16、32 次「恢复 → 续算 → 再保存」。GDN 在相同恢复次数下比较 INT8 与 BF16，平均绝对 logprob 差由 **0.0134（1 次）增至 0.0240（32 次）**。32 次时两组均答对 **31/32**、逐题对错一致，但完整生成序列只一致 **19/32**。固定 checkpoint 格式后，GDN 在所有测试次数下的 L1/L2 输出和逐 token logprob 完全一致；KDA 的 L1/L2 差异与重复运行波动同量级。这组小样本用于观察误差随连续恢复的变化，不能据此断言量化无损或长期精度等价。

## Supplementary Materials（补充材料）

补充材料包含支持配置、全部性能场景和逐轮数据、锁页内存测量、完整精度统计、连续恢复各深度的结果，以及 KDA 重复性诊断。验证基于独立 002 提交 `15a00b66a6b3`（基线 `af98fcd545f9`）；KDA 使用独立测试兼容层。完整远端 CI 仍待运行。
